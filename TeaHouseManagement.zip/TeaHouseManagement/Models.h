// Common/Models.h - CAU TRUC DU LIEU CHUNG (dung cho SalesModule)
// File nay duoc DUNG LAI tu cach SalesModule.cpp su dung (file goc chua co trong du an).
// Neu nhom da co Models.h chinh thuc, cu thay file nay bang file do.
//
// Ten truong da duoc THONG NHAT: chi dung  sotien  va  thanhtien  (chu thuong).
// Cac module khac neu dung soTien / thanhTien thi can doi lai cho khop.
#ifndef MODELS_H
#define MODELS_H

#include <string>
using namespace std;

// ---------------------------------------------------------------- Gioi han
const int MAX_CART_ITEMS  = 20;    // so dong toi da trong gio hang
const int MAX_ORDER_ITEMS = 20;    // so dong toi da trong 1 don (>= MAX_CART_ITEMS)
const int MAX_ORDERS      = 200;
const int MAX_PAYMENTS    = 200;
const int MAX_INVOICES    = 200;

// ----------------------------------------------------------- Loai san pham
const int ROOM_RENTAL    = 1;   // Thue phong
const int TEA_BY_POT     = 2;   // Tra theo am
const int PACKAGED_TEA   = 3;   // Tra dong goi
const int TEA_TOOL       = 4;   // Tra cu / am chen
const int TEA_EXPERIENCE = 5;   // Trai nghiem tra

// ------------------------------------------------------ Trang thai don hang
const int ORDER_PENDING   = 0;  // Chua thanh toan
const int ORDER_PAID      = 1;  // Da thanh toan
const int ORDER_CANCELLED = 2;  // Da huy
const int ORDER_REFUNDED  = 3;  // Da hoan tien

// ------------------------------------------------------ Trang thai thanh toan
const int PAYMENT_UNPAID   = 0;
const int PAYMENT_PAID     = 1;
const int PAYMENT_REFUNDED = 2;

// ------------------------------------------------------ Phuong thuc thanh toan
// (0 = chua chon, SalesModule in "Chua chon" khi khac 2 gia tri duoi day)
const int CASH          = 1;    // Tien mat
const int BANK_TRANSFER = 2;    // Chuyen khoan

// ------------------------------------------------------------ Cau truc du lieu
struct ItemDonHang {             // 1 dong san pham trong don
    string maitem, masp, tensp;
    int loaisp;
    double sl;
    long long giagoc;
    long long thanhtien;
    ItemDonHang() : loaisp(0), sl(0), giagoc(0), thanhtien(0) {}
};

struct DonHang {                 // don hang
    string madh, makh, tenkh, ngaytao;
    int trangthai;
    int datrukho;                // 1 = da tru kho
    int slsp;                    // so dong san pham
    long long tonggoc, giamgia, tongtien;
    ItemDonHang dssp[MAX_ORDER_ITEMS];
    DonHang() : trangthai(ORDER_PENDING), datrukho(0), slsp(0), tonggoc(0), giamgia(0), tongtien(0) {}
};

struct ThanhToan {               // 1 lan thanh toan cua 1 don
    string mathanhtoan, madh, tgianthanhtoan;
    long long sotien;
    int phuongthuc;
    int trangthai;
    ThanhToan() : sotien(0), phuongthuc(0), trangthai(PAYMENT_UNPAID) {}
};

struct HoaDon {                  // hoa don
    string mahd, madh, mathanhtoan, makh, tenkh, ngaytao;
    long long tongtien;
    HoaDon() : tongtien(0) {}
};

#endif
