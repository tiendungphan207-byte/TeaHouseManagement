// UserModule.h - KHAI BAO module quan ly tai khoan va phan quyen (ban rut gon)
// Cac module khac chi can #include "UserModule.h" roi goi hasAccess()/checkAccess().
#ifndef USERMODULE_H
#define USERMODULE_H

#include <string>
using namespace std;

const int MAX_ACCOUNTS  = 100;
const int FEATURE_COUNT = 7;

// Chuc nang cua phan mem. Quyen duoc quyet dinh THEO VAI TRO (khong luu rieng tung tai khoan)
const int F_VIEW_MENU = 0;   // xem thuc don, xem phong, xem lich trong
const int F_BOOKING   = 1;   // dat phong, xem/huy lich cua minh
const int F_SELL      = 2;   // ban hang
const int F_ROOM      = 3;   // quan ly phong va lich dat phong
const int F_INVENTORY = 4;   // quan ly kho tra
const int F_REVENUE   = 5;   // xem doanh thu
const int F_SCHEDULE  = 6;   // nghe nhan xem lich phuc vu
extern string featureName[FEATURE_COUNT];

// Ten cu de cac module viet truoc do van bien dich duoc
const int F_VIEW_INVENTORY = F_INVENTORY;
const int F_EDIT_INVENTORY = F_INVENTORY;
const int F_VIEW_REVENUE   = F_REVENUE;
const int F_VIEW_SCHEDULE  = F_SCHEDULE;

// ---------------------------------------------------------------- Tai khoan
class Account{
	public:
		int id;
		string fullName, phone, email, username, passwordHash, role;   // role: Owner/Staff/Artist/Customer
		bool locked;

		Account();
		Account(int i, string nam, string pho, string ema, string use, string hash, string rol);
		void display();   // in 1 dong trong danh sach
};

// ------------------------------------------------------------ Ham tien ich
string inputLine(string prompt);
int    inputInt(string prompt);          // tra ve -1 neu nhap sai
bool   isValidPhone(string s);
bool   isValidEmail(string s);
string hashPassword(string password);    // bam mat khau (muc co ban, xem ghi chu trong .cpp)
bool   roleHasFeature(string role, int feature);   // bang quyen theo vai tro

// ------------------------------------------------------------- UserModule
class UserModule{
	private:
		Account list[MAX_ACCOUNTS];   // du lieu an: ben ngoai chi dung qua cac ham ben duoi
		int count, nextId;
		string fileName;              // file luu tai khoan ("" = khong luu, dung khi kiem thu)

		string validateNew(string nam, string pho, string ema, string use, string pas);
		void   addInternal(string nam, string pho, string ema, string use, string hash, string rol);

	public:
		UserModule(string file = "accounts.txt");

		// Luu / doc file
		bool save();
		bool load();

		// Truy van thong tin (idx = vi tri tai khoan, Guest = -1)
		int    getCount();
		int    getId(int idx);
		string getRole(int idx);
		string getUsername(int idx);
		string getFullName(int idx);
		string getCustomerCode(int idx);   // ma khach cho SalesModule (makh), vi du "KH003"
		bool   isLocked(int idx);
		bool   isOwner(int idx);
		int    findByUsername(string username);
		int    findByPhone(string phone);
		int    findById(int id);

		// Thao tac tren tai khoan: tra ve "" neu thanh cong, nguoc lai la noi dung loi
		string addAccount(string nam, string pho, string ema, string use, string pas, string rol);
		string createAccount(int callerIdx, string nam, string pho, string ema, string use, string pas, string rol);
		string lockAccount(int callerIdx, int targetId, bool lockIt);
		string setPassword(int idx, string oldPass, string newPass);
		int    tryLogin(string use, string pas, string &message);   // tra ve idx hoac -1

		// Nhap tu ban phim (dung cho menu)
		void registerCustomer();
		void createStaffAccount(int callerIdx, string role);
		int  login();
		void toggleLock(int callerIdx);
		void changePassword(int idx);

		// Hien thi
		void showAll();
		void showOne(int idx);
		void showPermissions(int idx);

		// RBAC: cac module khac goi truoc khi cho nguoi dung vao chuc nang
		bool hasAccess(int idx, int feature);     // khong in gi
		bool checkAccess(int idx, int feature);   // in "[TU CHOI]" neu khong duoc
};

#endif
