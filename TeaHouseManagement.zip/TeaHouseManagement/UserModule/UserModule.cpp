// UserModule.cpp - CAI DAT module tai khoan va phan quyen (ban rut gon)
#include <iostream>
#include <fstream>
#include <cstdlib>
#include "UserModule.h"
using namespace std;

string featureName[FEATURE_COUNT] = {
	"Xem thuc don / phong", "Dat phong", "Ban hang", "Quan ly phong",
	"Quan ly kho tra", "Xem doanh thu", "Xem lich phuc vu"
};

// ================================================== Bang quyen theo vai tro
// Muon doi quyen cua vai tro nao thi sua dung o day, khong phai sua o cho khac.
bool roleHasFeature(string role, int feature){
	if(feature == F_VIEW_MENU) return true;            // ai cung xem duoc
	if(role == "Owner") return true;                   // chu quan: moi chuc nang
	if(role == "Staff")    return feature == F_BOOKING || feature == F_SELL
	                           || feature == F_ROOM || feature == F_SCHEDULE;
	if(role == "Artist")   return feature == F_SCHEDULE;
	if(role == "Customer") return feature == F_BOOKING;
	return false;
}

// ================================================================ Tien ich
// Bam mat khau kieu co ban (djb2 + muoi co dinh): mat khau KHONG con luu dang chu thuong.
// Day la muc do danh cho bai tap; he thong that se dung thuat toan nhu SHA-256/bcrypt.
string hashPassword(string password){
	unsigned int h = 5381;
	string s = "tea#" + password;
	for(unsigned i = 0; i < s.size(); i++){
		h = h * 33 + (unsigned char)s[i];
	}
	return to_string(h);
}

string inputLine(string prompt){
	string s;
	cout << prompt;
	getline(cin, s);
	return s;
}

int inputInt(string prompt){
	string s = inputLine(prompt);
	if(s.empty() || s.size() > 9) return -1;
	for(unsigned i = 0; i < s.size(); i++){
		if(s[i] < '0' || s[i] > '9') return -1;
	}
	return atoi(s.c_str());
}

bool isValidPhone(string s){
	if(s.size() < 8 || s.size() > 15) return false;
	for(unsigned i = 0; i < s.size(); i++){
		if(s[i] < '0' || s[i] > '9') return false;
	}
	return true;
}

bool isValidEmail(string s){
	size_t at = s.find('@');
	if(at == string::npos || at == 0) return false;
	if(s.find(' ') != string::npos) return false;
	size_t dot = s.find('.', at);
	return dot != string::npos && dot > at + 1 && dot < s.size() - 1;
}

// ===================================================================== Account
Account::Account(){
	id = 0;
	locked = false;
}

Account::Account(int i, string nam, string pho, string ema, string use, string hash, string rol){
	id = i;
	fullName = nam;
	phone = pho;
	email = ema;
	username = use;
	passwordHash = hash;
	role = rol;
	locked = false;
}

void Account::display(){
	cout << id << "\t" << username << "\t" << role << "\t" << fullName << "\t" << phone
	     << "\t" << (locked ? "BI KHOA" : "Hoat dong") << "\n";
}

// ================================================================= UserModule
UserModule::UserModule(string file){
	count = 0;
	nextId = 1;
	fileName = file;
	load();
	// Chua co tai khoan Owner (lan chay dau hoac file hong) -> tao Owner mac dinh
	bool hasOwner = false;
	for(int i = 0; i < count; i++){
		if(list[i].role == "Owner") hasOwner = true;
	}
	if(!hasOwner){
		addInternal("Chu Phong Tra", "0900000000", "owner@teahouse.vn", "owner", hashPassword("owner123"), "Owner");
		save();
	}
}

// ---------------------------------------------------------------- Luu / doc file
// Moi tai khoan 1 dong: id|ho ten|sdt|email|username|hash|vai tro|khoa(0/1)
bool UserModule::save(){
	if(fileName == "") return true;
	ofstream f(fileName.c_str());
	if(!f) return false;
	for(int i = 0; i < count; i++){
		Account &a = list[i];
		f << a.id << "|" << a.fullName << "|" << a.phone << "|" << a.email << "|"
		  << a.username << "|" << a.passwordHash << "|" << a.role << "|" << (a.locked ? 1 : 0) << "\n";
	}
	return true;
}

bool UserModule::load(){
	if(fileName == "") return false;
	ifstream f(fileName.c_str());
	if(!f) return false;
	string line;
	while(getline(f, line) && count < MAX_ACCOUNTS){
		string part[8];
		int n = 0;
		size_t start = 0;
		while(n < 7){
			size_t p = line.find('|', start);
			if(p == string::npos) break;
			part[n++] = line.substr(start, p - start);
			start = p + 1;
		}
		if(n != 7) continue;               // dong hong -> bo qua
		part[7] = line.substr(start);
		int id = atoi(part[0].c_str());
		string role = part[6];
		if(id < 1 || part[4].empty() || part[5].empty()) continue;
		if(role != "Owner" && role != "Staff" && role != "Artist" && role != "Customer") continue;
		list[count] = Account(id, part[1], part[2], part[3], part[4], part[5], role);
		list[count].locked = (part[7] == "1");
		count++;
		if(id >= nextId) nextId = id + 1;
	}
	return true;
}

// ---------------------------------------------------------------- Truy van
int UserModule::getCount(){ return count; }

int UserModule::getId(int idx){
	if(idx < 0 || idx >= count) return -1;
	return list[idx].id;
}

string UserModule::getRole(int idx){
	if(idx < 0 || idx >= count) return "Guest";
	return list[idx].role;
}

string UserModule::getUsername(int idx){
	if(idx < 0 || idx >= count) return "";
	return list[idx].username;
}

string UserModule::getFullName(int idx){
	if(idx < 0 || idx >= count) return "";
	return list[idx].fullName;
}

// Ma khach hang dung cho DonHang.makh / HoaDon.makh cua SalesModule
string UserModule::getCustomerCode(int idx){
	if(idx < 0 || idx >= count) return "";
	string n = to_string(list[idx].id);
	while(n.size() < 3) n = "0" + n;
	return "KH" + n;
}

bool UserModule::isLocked(int idx){
	if(idx < 0 || idx >= count) return false;
	return list[idx].locked;
}

bool UserModule::isOwner(int idx){
	return getRole(idx) == "Owner" && !list[idx].locked;
}

int UserModule::findByUsername(string username){
	for(int i = 0; i < count; i++){
		if(list[i].username == username) return i;
	}
	return -1;
}

int UserModule::findByPhone(string phone){
	for(int i = 0; i < count; i++){
		if(list[i].phone == phone) return i;
	}
	return -1;
}

int UserModule::findById(int id){
	for(int i = 0; i < count; i++){
		if(list[i].id == id) return i;
	}
	return -1;
}

// ------------------------------------------------------- Tao tai khoan
// Kiem tra du lieu; tra ve "" neu hop le, nguoc lai tra ve noi dung loi
string UserModule::validateNew(string nam, string pho, string ema, string use, string pas){
	if(nam.empty() || pho.empty() || ema.empty() || use.empty() || pas.empty())
		return "Khong duoc de trong thong tin bat buoc.";
	string all = nam + pho + ema + use;
	if(all.find('|') != string::npos) return "Thong tin khong duoc chua ky tu '|'.";
	if(!isValidPhone(pho)) return "So dien thoai phai gom 8-15 chu so.";
	if(!isValidEmail(ema)) return "Email khong hop le.";
	if(use.find(' ') != string::npos) return "Ten dang nhap khong duoc co dau cach.";
	if(pas.size() < 6) return "Mat khau phai co it nhat 6 ky tu.";
	if(findByUsername(use) != -1) return "Ten dang nhap da ton tai.";
	if(findByPhone(pho) != -1) return "So dien thoai da duoc dang ky.";
	if(count >= MAX_ACCOUNTS) return "Danh sach tai khoan da day.";
	return "";
}

void UserModule::addInternal(string nam, string pho, string ema, string use, string hash, string rol){
	list[count] = Account(nextId, nam, pho, ema, use, hash, rol);
	count++;
	nextId++;
}

// Ham them tai khoan tu kiem tra du lieu va gioi han mang. Khong cho tao Owner moi.
string UserModule::addAccount(string nam, string pho, string ema, string use, string pas, string rol){
	if(rol != "Staff" && rol != "Artist" && rol != "Customer") return "Vai tro khong hop le.";
	string err = validateNew(nam, pho, ema, use, pas);
	if(err != "") return err;
	addInternal(nam, pho, ema, use, hashPassword(pas), rol);
	save();
	return "";
}

// Chi Owner moi tao duoc Staff / Artist
string UserModule::createAccount(int callerIdx, string nam, string pho, string ema, string use, string pas, string rol){
	if(!isOwner(callerIdx)) return "Chi Owner moi duoc tao tai khoan nhan vien.";
	if(rol != "Staff" && rol != "Artist") return "Owner chi tao duoc Staff hoac Artist.";
	return addAccount(nam, pho, ema, use, pas, rol);
}

string UserModule::lockAccount(int callerIdx, int targetId, bool lockIt){
	if(!isOwner(callerIdx)) return "Chi Owner moi duoc khoa/mo khoa tai khoan.";
	int t = findById(targetId);
	if(t == -1) return "Khong tim thay tai khoan.";
	if(list[t].role == "Owner") return "Khong the khoa tai khoan Owner.";
	list[t].locked = lockIt;
	save();
	return "";
}

string UserModule::setPassword(int idx, string oldPass, string newPass){
	if(idx < 0 || idx >= count) return "Ban can dang nhap.";
	if(list[idx].passwordHash != hashPassword(oldPass)) return "Mat khau hien tai khong dung.";
	if(newPass.size() < 6) return "Mat khau moi phai co it nhat 6 ky tu.";
	list[idx].passwordHash = hashPassword(newPass);
	save();
	return "";
}

int UserModule::tryLogin(string use, string pas, string &message){
	int idx = findByUsername(use);
	if(idx == -1 || list[idx].passwordHash != hashPassword(pas)){
		message = "Dang nhap that bai: sai ten dang nhap hoac mat khau.";
		return -1;
	}
	if(list[idx].locked){
		message = "Dang nhap that bai: tai khoan da bi khoa. Hay lien he Owner.";
		return -1;
	}
	message = "Dang nhap thanh cong! Xin chao " + list[idx].fullName + " (vai tro: " + list[idx].role + ").";
	return idx;
}

// ------------------------------------------------------ Nhap tu ban phim
void UserModule::registerCustomer(){
	cout << "\n--- DANG KY TAI KHOAN ---\n";
	string nam = inputLine("Ho ten: ");
	string pho = inputLine("So dien thoai: ");
	string ema = inputLine("Email: ");
	string use = inputLine("Ten dang nhap: ");
	string pas = inputLine("Mat khau (>= 6 ky tu): ");
	string err = addAccount(nam, pho, ema, use, pas, "Customer");
	if(err != "") cout << "Dang ky that bai: " << err << "\n";
	else cout << "Dang ky thanh cong! Ban co the dang nhap bang tai khoan '" << use << "'.\n";
}

void UserModule::createStaffAccount(int callerIdx, string role){
	cout << "\n--- TAO TAI KHOAN " << role << " ---\n";
	string nam = inputLine("Ho ten: ");
	string pho = inputLine("So dien thoai: ");
	string ema = inputLine("Email: ");
	string use = inputLine("Ten dang nhap: ");
	string pas = inputLine("Mat khau (>= 6 ky tu): ");
	string err = createAccount(callerIdx, nam, pho, ema, use, pas, role);
	if(err != "") cout << "Tao tai khoan that bai: " << err << "\n";
	else cout << "Da tao tai khoan " << role << " '" << use << "'.\n";
}

int UserModule::login(){
	cout << "\n--- DANG NHAP ---\n";
	string use = inputLine("Ten dang nhap: ");
	string pas = inputLine("Mat khau: ");
	string msg;
	int idx = tryLogin(use, pas, msg);
	cout << msg << "\n";
	return idx;
}

void UserModule::toggleLock(int callerIdx){
	showAll();
	int id = inputInt("Nhap ma tai khoan can khoa/mo khoa: ");
	int t = findById(id);
	if(t == -1){ cout << "Khong tim thay tai khoan.\n"; return; }
	bool newState = !list[t].locked;
	string err = lockAccount(callerIdx, id, newState);
	if(err != "") cout << "Khong thuc hien duoc: " << err << "\n";
	else cout << (newState ? "Da khoa" : "Da mo khoa") << " tai khoan '" << list[t].username << "'.\n";
}

void UserModule::changePassword(int idx){
	string oldPass = inputLine("Mat khau hien tai: ");
	string newPass = inputLine("Mat khau moi (>= 6 ky tu): ");
	string err = setPassword(idx, oldPass, newPass);
	if(err != "") cout << "Doi mat khau that bai: " << err << "\n";
	else cout << "Da doi mat khau.\n";
}

// ----------------------------------------------------------------- Hien thi
void UserModule::showAll(){
	cout << "\nID\tTai khoan\tVai tro\tHo ten\tSDT\tTrang thai\n";
	for(int i = 0; i < count; i++) list[i].display();
}

void UserModule::showOne(int idx){
	if(idx < 0 || idx >= count){ cout << "Ban chua dang nhap (Guest).\n"; return; }
	Account &a = list[idx];
	cout << "\n--- THONG TIN TAI KHOAN ---\n";
	cout << "Ma           : " << a.id << "\n";
	cout << "Ho ten       : " << a.fullName << "\n";
	cout << "So dien thoai: " << a.phone << "\n";
	cout << "Email        : " << a.email << "\n";
	cout << "Ten dang nhap: " << a.username << "\n";
	cout << "Vai tro      : " << a.role << "\n";
	cout << "Trang thai   : " << (a.locked ? "Bi khoa" : "Hoat dong") << "\n";
}

void UserModule::showPermissions(int idx){
	string role = getRole(idx);
	cout << "\nVai tro hien tai: " << role << "\n";
	for(int i = 0; i < FEATURE_COUNT; i++){
		cout << "  " << featureName[i] << " : " << (hasAccess(idx, i) ? "DUOC PHEP" : "khong duoc phep") << "\n";
	}
}

// ----------------------------------------------------------------- RBAC
bool UserModule::hasAccess(int idx, int feature){
	if(feature < 0 || feature >= FEATURE_COUNT) return false;
	if(idx == -1) return feature == F_VIEW_MENU;      // Guest chi xem
	if(idx < 0 || idx >= count) return false;
	if(list[idx].locked) return false;                // tai khoan bi khoa: khong lam duoc gi
	return roleHasFeature(list[idx].role, feature);
}

bool UserModule::checkAccess(int idx, int feature){
	if(hasAccess(idx, feature)) return true;
	cout << "[TU CHOI] Vai tro " << getRole(idx) << " khong co quyen: "
	     << (feature >= 0 && feature < FEATURE_COUNT ? featureName[feature] : "?") << "\n";
	return false;
}
