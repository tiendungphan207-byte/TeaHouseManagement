#include <iostream>
#include <string>
#include <vector>

using namespace std;

// Cấu trúc Nghệ nhân
struct Artisan
{
    string artisanID;
    string name;
    string specialty;
};

// Cấu trúc Buổi trải nghiệm
struct TeaSession
{
    string sessionID;
    string artisanID;
    string title;
    string dateTime;
    int maxParticipants;
    int currentRegistered = 0;
    double price;
    bool isActive = true;
};

// Cấu trúc Đăng ký
struct Registration
{
    string regID;
    string customerUsername;
    string sessionID;
    string status; 
};

class TeaCulturalSpace
{
private:
    vector<Artisan> artisans;
    vector<TeaSession> sessions;
    vector<Registration> registrations;

public:
    void loadData(); 
    void saveData(); 

    // Menu chức năng
    void customerMenu();
    void artisanMenu();
};

int main()
{
    TeaCulturalSpace space;
    int choice;
    do
    {
        cout << "\n=== PHAN MEM QUAN LY PHONG TRA & KHONG GIAN VAN HOA TRA ==-\n";
        cout << "1. Dang nhap voi tu cach Khach hang\n";
        cout << "2. Dang nhap voi tu cach Nghe nhan\n";
        cout << "0. Thoat\n";
        cout << "Lua chon cua ban: ";
        cin >> choice;

        switch (choice)
        {
            // Xử lý điều hướng menu tại đây
        }
    } while (choice != 0);

    return 0;
}