#include <iostream>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

// 1. Struct quan ly dung cu tra dao đi kèm
struct TeaUtensil {
    string utensilName; 
    int quantity;       
};

// 2. Struct quan ly Khach tham gia & Check-in
struct Participant {
    string customerId;  
    string fullName;    
    string workshopId;  
    bool isCheckedIn;   
};

// 3. Struct quan ly san pham tra thu cong ban kem
struct ProductSale {
    string productName; 
    double unitPrice;   
    int quantitySold; 
};

// 4. Struct Hoat dong trai nghiem (Workshop)
struct TeaActivity {
    string id;                  
    string title;               
    double fee;                 
    int maxCapacity;            
    int currentBooked;         
    vector<TeaUtensil> utensils;
};  
int main() {
    vector<TeaActivity> activities;
    vector<Participant> participants;
    vector<ProductSale> products = {
        {"Tra Sen Ho Tay (Hop 100g)", 350000, 5},
        {"Tra Oolong Thuong Hang (Hop 200g)", 250000, 8},
        {"Bo am chen Tu Sa mini", 1200000, 2}
    }; // Du lieu mau san pham tra ban thu cong

    int choice;
    do {
        cout << "\n================ QUAN LY KHONG GIAN VAN HOA TRA ================\n";
        cout << "1. Xem danh sach hoat dong & Dung cu di kem\n";
        cout << "2. Them hoat dong moi (Co nhap dung cu)\n";
        cout << "3. Dang ky tham gia Workshop\n";
        cout << "4. He thong Check-in khach tham gia\n";
        cout << "5. Bao cao doanh thu (Hoc phi + Ban san pham)\n";
        cout << "0. Thoat chuong trinh\n";
        cout << "Lua chon cua ban: ";
        cin >> choice;

        if (choice == 1) {
            cout << "\n--- DANH SACH HOAT DONG & DUNG CU ---\n";
            if (activities.empty()) {
                cout << "Chua co hoat dong nao!\n";
            } else {
                for (size_t i = 0; i < activities.size(); i++) {
                    cout << i + 1 << ". Ma: " << activities[i].id 
                         << " | Ten: " << activities[i].title 
                         << " | Gia: " << fixed << setprecision(0) << activities[i].fee << " VND"
                         << " | Da DK: " << activities[i].currentBooked << "/" << activities[i].maxCapacity << "\n";
                    cout << "    -> Dung cu can chuan bi:\n";
                    for (const auto& u : activities[i].utensils) {
                        cout << "      - " << u.utensilName << " (So luong: " << u.quantity << ")\n";
                    }
                }
            }
        } 
        else if (choice == 2) {
            TeaActivity act;
            cout << "Nhap ma hoat dong (VD: WS01): "; cin >> act.id;
            cin.ignore();
            cout << "Nhap ten hoat dong: "; getline(cin, act.title);
            cout << "Nhap hoc phi (VND): "; cin >> act.fee;
            cout << "Nhap so cho toi da: "; cin >> act.maxCapacity;
            act.currentBooked = 0;

            // Them dung cu đi kèm
            int numUtensils;
            cout << "Nhap so luong loai dung cu can thiet cho workshop nay: ";
            cin >> numUtensils;
            cin.ignore();
            for (int j = 0; j < numUtensils; j++) {
                TeaUtensil u;
                cout << "  - Ten dung cu thu " << j + 1 << " (VD: Am Tu Sa): "; getline(cin, u.utensilName);
                cout << "  - So luong can: "; cin >> u.quantity;
                cin.ignore();
                act.utensils.push_back(u);
            }

            activities.push_back(act);
            cout << "[Thanh cong] Da them hoat dong va kiem ke dung cu!\n";
        }
        else if (choice == 3) {
            string pId, name, wsId;
            cout << "Nhap ma khach hang (VD: KH01): "; cin >> pId;
            cin.ignore();
            cout << "Nhap ho ten khach hang: "; getline(cin, name);
            cout << "Nhap ma workshop muon dang ky: "; cin >> wsId;

            // Tim workshop de tang so luong dang ky
            bool found = false;
            for (auto& act : activities) {
                if (act.id == wsId) {
                    found = true;
                    if (act.currentBooked < act.maxCapacity) {
                        act.currentBooked++;
                        participants.push_back({pId, name, wsId, false}); // Mac dinh chua check-in
                        cout << "[Thanh cong] Khach hang " << name << " da dang ky thanh cong!\n";
                    } else {
                        cout << "[Thong bao] Workshop nay da het cho!\n";
                    }
                    break;
                }
            }
            if (!found) cout << "[Loi] Khong tim thay ma workshop!\n";
        }
        else if (choice == 4) {
            string pId;
            cout << "\n--- HE THONG CHECK-IN KHACH HANG ---\n";
            cout << "Nhap ma khach hang can check-in: "; cin >> pId;

            bool checked = false;
            for (auto& p : participants) {
                if (p.customerId == pId) {
                    checked = true;
                    if (!p.isCheckedIn) {
                        p.isCheckedIn = true;
                        cout << "[Check-in Thanh cong] Chao mung " << p.fullName << " den voi khong gian van hoa tra!\n";
                    } else {
                        cout << "[Thong bao] Khach hang nay da check-in truoc do roi!\n";
                    }
                    break;
                }
            }
            if (!checked) cout << "[Loi] Khong tim thay ma khach hang trong danh sach dang ky!\n";
        }
        else if (choice == 5) {
            // Tinh doanh thu hoc phi workshop
            double workshopRevenue = 0;
            for (const auto& act : activities) {
                workshopRevenue += (act.fee * act.currentBooked);
            }

            // Tinh doanh thu ban san pham tra thu cong
            double productRevenue = 0;
            cout << "\n================ BAO CAO DOANH THU ================\n";
            cout << "1. Doanh thu tu san pham tra thu cong:\n";
            for (const auto& p : products) {
                double subTotal = p.unitPrice * p.quantitySold;
                productRevenue += subTotal;
                cout << "   - " << p.productName << " | Da ban: " << p.quantitySold 
                     << " | Thanh tien: " << fixed << setprecision(0) << subTotal << " VND\n";
            }

            cout << "---------------------------------------------------\n";
            cout << " Tong doanh thu hoc phi Workshop: " << workshopRevenue << " VND\n";
            cout << " Tong doanh thu ban san pham:     " << productRevenue << " VND\n";
            cout << " => TONG DOANH THU TOAN HE THONG:  " << (workshopRevenue + productRevenue) << " VND\n";
            cout << "==================================================-\n";

            // Thong ke ty le hien dien (Check-in)
            if (!participants.empty()) {
                int checkedCount = 0;
                for (const auto& p : participants) {
                    if (p.isCheckedIn) checkedCount++;
                }
                double rate = (double)checkedCount / participants.size() * 100;
                cout << " Thong ke hien dien: " << checkedCount << "/" << participants.size() 
                     << " khach da tham gia (Ty le: " << fixed << setprecision(1) << rate << "%)\n";
            }
        }

    } while (choice != 0);

    return 0;
}