#include <stdio.h>
#include <string.h>
#include "artist.h"

// Hàm in thông tin chi tiết của 1 nghệ nhân
void inThongTinNgheNhan(NgheNhan nn) {
    printf("\n=== HO SO NGHE NHAN [%s] ===\n", nn.maNgheNhan);
    printf("Ho ten: %s - Chuc vu: %s\n", nn.hoTen, nn.chucVu);
    printf("Kinh nghiem: %d nam\n", nn.kinhNghiem);
    printf("Chuyen mon: %s\n", nn.chuyenMon);
    printf("Loai tra am hieu: %s\n", nn.loaiTraAmHieu);
    printf("Dich vu phu trach: %s\n", nn.dichVu);
    printf("Lich lam viec: %s\n", nn.lichLamViec);
    
    // In trạng thái dạng văn bản trực quan
    printf("Trang thai hien tai: ");
    switch (nn.trangThai) {
        case TRANG_THAI_TRONG:
            printf("[ Dang trong - San sang ]\n");
            break;
        case TRANG_THAI_DA_DAT:
            printf("[ Da co nguoi dat lich ]\n");
            break;
        case TRANG_THAI_NGHI:
            printf("[ Dang tam nghi ]\n");
            break;
    }
    printf("----------------------------------\n");
}