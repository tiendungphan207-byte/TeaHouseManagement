#define ARTIST_H
#define ARTIST_H

#define MAX_STR 100

// Định nghĩa Enum cho trạng thái làm việc để code rõ nghĩa hơn
typedef enum
{
    TRANG_THAI_TRONG = 0,  
    TRANG_THAI_DA_DAT = 1, 
    TRANG_THAI_NGHI = 2    
} TrangThaiLamViec;

typedef struct
{
    char maNgheNhan[20];      
    char hoTen[MAX_STR];         
    char tieuSu[300];           
    char chuyenMon[MAX_STR];     
    char loaiTraAmHieu[MAX_STR]; 
    char chucVu[MAX_STR];        
    char lichLamViec[MAX_STR];   
    TrangThaiLamViec trangThai;  
    char dichVu[MAX_STR];       
    int kinhNghiem;
} NgheNhan;
