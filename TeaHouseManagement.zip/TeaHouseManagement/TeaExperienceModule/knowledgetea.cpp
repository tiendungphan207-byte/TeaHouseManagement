#include <iostream>
#include <string>
#include <vector>
#include <iomanip>

struct TeaRecipe {
    std::string name;          
    std::string origin;        
    std::string amount;       
    int waterTemp;            
    int steepTimeSeconds;      
    int maxInfusions;          
    std::string utensilType;   
    std::string tastingMethod; 
    std::string flavorProfile; 
};