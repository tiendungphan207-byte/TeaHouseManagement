#include <iostream>
#include <string>
#include <vector>

struct Feedback {
    int feedbackId;        
    std::string customerName;   
    std::string artisanName;   
    int ratingArtisan;      
    int ratingExperience;  
    std::string comment;   
    std::string date;       
};