#include "SalesModule.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <chrono>
#include <ctime>
using namespace std;

SalesModule::SalesModule() {
    slgiohang = sldh = slthanhtoan = slhd = 0;
    sttdh = sttsp = sttthanhtoan = stthd = 0;
    docdata();
}

string SalesModule::taoMa(string tiento, int &stt) {
    string ma = to_string(++stt);
    while (ma.length() < 4) ma = "0" + ma;
    return tiento + ma;
}

string SalesModule::laytg() {
    char t[20];
    time_t now = time(NULL);
    struct tm *local = localtime(&now);
    strftime(t, sizeof(t), "%Y-%m-%d %H:%M:%S", local);
    return string(t);
}

int SalesModule::timdh(string ma) {
    for (int i = 0; i < sldh; i++) if (dh[i].madh == ma) return i;
    return -1;
}

long long SalesModule::totalgiohang() {
    long long tong = 0;
    for (int i = 0; i < slgiohang; i++) tong += (long long)(giohang[i].sl * giohang[i].giagoc + 0.5);
    return tong;
}

void SalesModule::taogiohang(string ma, string ten) {
    slgiohang = 0; makh = ma; tenkh = ten;
    cout << "Da tao gio hang cho " << ten << "\n";
}

int SalesModule::themvaogiohang(string ma, string ten, int loai, double sl, long long gia) {
    if (slgiohang >= MAX_CART_ITEMS || sl <= 0 || gia < 0) return 0;
    if (loai < ROOM_RENTAL || loai > TEA_EXPERIENCE) return 0;
    SPGioHang &x = giohang[slgiohang++];
    x.masp = ma; x.tensp = ten; x.loaisp = loai;
    x.sl = sl; x.giagoc = gia;
    return 1;
}

int SalesModule::xoakhoigiohang(int vitri) {
    if (vitri < 1 || vitri > slgiohang) return 0;
    for (int i = vitri - 1; i < slgiohang - 1; i++) giohang[i] = giohang[i + 1];
    slgiohang--; return 1;
}

int SalesModule::capnhatsl(int vitri, double sl) {
    if (vitri < 1 || vitri > slgiohang || sl <= 0) return 0;
    giohang[vitri - 1].sl = sl; return 1;
}

void SalesModule::hienthigiohang() {
    if (slgiohang == 0) { cout << "Gio hang dang trong.\n"; return; }
    cout << "\n--- GIO HANG ---\n";
    for (int i = 0; i < slgiohang; i++)
        cout << i + 1 << ". " << giohang[i].tensp << " | SL: " << giohang[i].sl
             << " | Don gia: " << giohang[i].giagoc << " | Thanh tien: "
             << (long long)(giohang[i].sl * giohang[i].giagoc + 0.5) << " VND\n";
    cout << "Tong tien: " << totalgiohang() << " VND\n";
}

string SalesModule::taodh() {
    if (slgiohang == 0 || sldh >= MAX_ORDERS || slthanhtoan >= MAX_PAYMENTS) return "";
    DonHang d;
    d.madh = taoMa("ORD", sttdh); d.makh = makh; d.tenkh = tenkh;
    d.slsp = slgiohang; d.tonggoc = totalgiohang(); d.giamgia = 0;
    d.tongtien = d.tonggoc; d.trangthai = ORDER_PENDING; d.datrukho = 0; d.ngaytao = laytg();
    for (int i = 0; i < slgiohang; i++) {
        ItemDonHang &x = d.dssp[i];
        x.maitem = taoMa("ITM", sttsp); x.masp = giohang[i].masp; x.tensp = giohang[i].tensp;
        x.loaisp = giohang[i].loaisp; x.sl = giohang[i].sl; x.giagoc = giohang[i].giagoc;
        x.thanhtien = (long long)(x.sl * x.giagoc + 0.5);
    }
    dh[sldh++] = d;
    
    ThanhToan t;
    t.mathanhtoan = taoMa("PAY", sttthanhtoan); t.madh = d.madh; t.sotien = d.tongtien;
    t.phuongthuc = 0; t.trangthai = PAYMENT_UNPAID; t.tgianthanhtoan = ""; thanhtoan[slthanhtoan++] = t;
    
    slgiohang = 0; luudata();
    return d.madh;
}

void SalesModule::hienthidh() {
    cout << "\n--- DANH SACH DON HANG ---\n";
    for (int i = 0; i < sldh; i++) {
        cout << dh[i].madh << " | " << dh[i].tenkh << " | " << dh[i].tongtien << " VND | ";
        if (dh[i].trangthai == ORDER_PENDING) cout << "Chua thanh toan";
        else if (dh[i].trangthai == ORDER_PAID) cout << "Da thanh toan";
        else cout << "Da huy";
        cout << " | " << dh[i].ngaytao << "\n";
    }
}

void SalesModule::hienthidh(string ma) {
    int k = timdh(ma);
    if (k == -1) { cout << "Khong tim thay don hang.\n"; return; }
    cout << "Ma don: " << ma << " | Khach: " << dh[k].tenkh << "\n";
    for (int i = 0; i < dh[k].slsp; i++)
        cout << dh[k].dssp[i].tensp << " | SL: " << dh[k].dssp[i].sl
             << " | " << dh[k].dssp[i].thanhtien << " VND\n";
    cout << "Tong tien: " << dh[k].tongtien << " VND\n";
}

void SalesModule::timtheokh(string ma) {
    int timthay = 0;
    for (int i = 0; i < sldh; i++) if (dh[i].makh == ma) {
        cout << dh[i].madh << " | " << dh[i].tenkh << " | " << dh[i].tongtien << " VND\n";
        timthay++;
    }
    if (timthay == 0) cout << "Khong co don hang cua khach nay.\n";
}

void SalesModule::timtheongay(string ngay) {
    int timthay = 0;
    for (int i = 0; i < sldh; i++) if (dh[i].ngaytao.substr(0, 10) == ngay) {
        cout << dh[i].madh << " | " << dh[i].tenkh << " | " << dh[i].tongtien << " VND\n";
        timthay++;
    }
    if (timthay == 0) cout << "Khong co don hang trong ngay nay.\n";
}

int SalesModule::huydh(string ma) {
    int k = timdh(ma);
    if (k == -1 || dh[k].trangthai != ORDER_PENDING) return 0;
    dh[k].trangthai = ORDER_CANCELLED; luudata(); return 1;
}

void SalesModule::taohoadon(int k, int p) {
    HoaDon v;
    v.mahd = taoMa("INV", stthd); v.madh = dh[k].madh; v.mathanhtoan = thanhtoan[p].mathanhtoan;
    v.makh = dh[k].makh; v.tenkh = dh[k].tenkh;
    v.tongtien = dh[k].tongtien; v.ngaytao = laytg(); hd[slhd++] = v;
}

int SalesModule::thanhtoandh(string ma, int phuongthuc) {
    int k = timdh(ma), p = -1;
    if (k == -1 || dh[k].trangthai != ORDER_PENDING) return 0;
    if ((phuongthuc != CASH && phuongthuc != BANK_TRANSFER) || slhd >= MAX_INVOICES) return 0;
    for (int i = 0; i < slthanhtoan; i++) if (thanhtoan[i].madh == ma) p = i;
    if (p == -1 || thanhtoan[p].trangthai != PAYMENT_UNPAID) return 0;
    thanhtoan[p].phuongthuc = phuongthuc; thanhtoan[p].trangthai = PAYMENT_PAID; thanhtoan[p].tgianthanhtoan = laytg();
    dh[k].trangthai = ORDER_PAID; taohoadon(k, p); luudata(); return 1;
}

void SalesModule::hienthithanhtoan() {
    cout << "\n--- LICH SU THANH TOAN ---\n";
    for (int i = 0; i < slthanhtoan; i++) {
        cout << thanhtoan[i].mathanhtoan << " | " << thanhtoan[i].madh << " | " << thanhtoan[i].sotien << " VND | ";
        if (thanhtoan[i].phuongthuc == CASH) cout << "Tien mat";
        else if (thanhtoan[i].phuongthuc == BANK_TRANSFER) cout << "Chuyen khoan";
        else cout << "Chua chon";
        cout << " | ";
        if (thanhtoan[i].trangthai == PAYMENT_UNPAID) cout << "Chua thanh toan";
        else cout << "Da thanh toan";
        cout << " | " << thanhtoan[i].tgianthanhtoan << "\n";
    }
}

void SalesModule::hienthihoadon(string ma) {
    for (int i = 0; i < slhd; i++) if (hd[i].mahd == ma || hd[i].madh == ma) {
        cout << "\n========== HOA DON ==========\nMa hoa don: " << hd[i].mahd
             << "\nMa don: " << hd[i].madh << "\nKhach: " << hd[i].tenkh << "\n";
        int k = timdh(hd[i].madh);
        if (k != -1) for (int j = 0; j < dh[k].slsp; j++)
            cout << dh[k].dssp[j].tensp << " | " << dh[k].dssp[j].sl
                 << " | " << dh[k].dssp[j].thanhtien << " VND\n";
        cout << "Tong tien: " << hd[i].tongtien << " VND\nThoi gian: " << hd[i].ngaytao << "\n";
        return;
    }
    cout << "Khong tim thay hoa don.\n";
}


void SalesModule::doanhthutheongay(string ngay) {
    long long total = 0;
    for (int i = 0; i < slthanhtoan; i++)
        if (thanhtoan[i].trangthai == PAYMENT_PAID && thanhtoan[i].tgianthanhtoan.substr(0, 10) == ngay) total += thanhtoan[i].sotien;
    cout << "Doanh thu ngay " << ngay << ": " << total << " VND\n";
}

int SalesModule::layslspdh(string ma) {
    int k = timdh(ma); return k == -1 ? 0 : dh[k].slsp;
}

int SalesModule::layspdh(string ma, int vitri, ItemDonHang &sp) {
    int k = timdh(ma);
    if (k == -1 || vitri < 0 || vitri >= dh[k].slsp) return 0;
    sp = dh[k].dssp[vitri]; return 1;
}

int SalesModule::danhdautrukho(string ma) {
    int k = timdh(ma);
    if (k == -1 || dh[k].trangthai != ORDER_PAID || dh[k].datrukho == 1) return 0;
    dh[k].datrukho = 1; luudata(); return 1;
}

void SalesModule::luudata() {
    ofstream f("orders.txt"); f << sldh << '\n';
    for (int i = 0; i < sldh; i++) {
        DonHang &o = dh[i];
        f << o.madh << '\n' << o.makh << '\n' << o.tenkh << '\n' << o.ngaytao << '\n'
          << o.trangthai << ' ' << o.datrukho << ' ' << o.slsp << ' ' << o.tonggoc << ' ' << o.giamgia << ' ' << o.tongtien << '\n';
        for (int j = 0; j < o.slsp; j++) {
            ItemDonHang &x = o.dssp[j];
            f << x.maitem << '\n' << x.masp << '\n' << x.tensp << '\n'
              << x.loaisp << ' ' << setprecision(10) << x.sl << ' ' << x.giagoc << ' ' << x.thanhtien << '\n';
        }
    }
    ofstream p("payments.txt"); p << slthanhtoan << '\n';
    for (int i = 0; i < slthanhtoan; i++)
        p << thanhtoan[i].mathanhtoan << '\n' << thanhtoan[i].madh << '\n' << thanhtoan[i].tgianthanhtoan << '\n'
          << thanhtoan[i].sotien << ' ' << thanhtoan[i].phuongthuc << ' ' << thanhtoan[i].trangthai << '\n';
    ofstream v("invoices.txt"); v << slhd << '\n';
    for (int i = 0; i < slhd; i++)
        v << hd[i].mahd << '\n' << hd[i].madh << '\n' << hd[i].mathanhtoan << '\n'
          << hd[i].makh << '\n' << hd[i].tenkh << '\n' << hd[i].ngaytao
          << '\n' << hd[i].tongtien << '\n';
}

void SalesModule::docdata() {
    ifstream f("orders.txt");
    if (f >> sldh) {
        f.ignore(10000, '\n');
        if (sldh < 0 || sldh > MAX_ORDERS) sldh = 0;
        for (int i = 0; i < sldh; i++) {
            DonHang &o = dh[i];
            getline(f, o.madh); getline(f, o.makh); getline(f, o.tenkh); getline(f, o.ngaytao);
            f >> o.trangthai >> o.datrukho >> o.slsp >> o.tonggoc >> o.giamgia >> o.tongtien; f.ignore(10000, '\n');
            if (o.slsp < 0 || o.slsp > MAX_ORDER_ITEMS) { sldh = 0; break; }
            for (int j = 0; j < o.slsp; j++) {
                ItemDonHang &x = o.dssp[j];
                getline(f, x.maitem); getline(f, x.masp); getline(f, x.tensp);
                f >> x.loaisp >> x.sl >> x.giagoc >> x.thanhtien; f.ignore(10000, '\n');
            }
            sttsp += o.slsp;
        }
        sttdh = sldh;
    }
    ifstream p("payments.txt");
    if (p >> slthanhtoan) {
        p.ignore(10000, '\n');
        if (slthanhtoan < 0 || slthanhtoan > MAX_PAYMENTS) slthanhtoan = 0;
        for (int i = 0; i < slthanhtoan; i++) {
            getline(p, thanhtoan[i].mathanhtoan); getline(p, thanhtoan[i].madh); getline(p, thanhtoan[i].tgianthanhtoan);
            p >> thanhtoan[i].sotien >> thanhtoan[i].phuongthuc >> thanhtoan[i].trangthai; p.ignore(10000, '\n');
        }
        sttthanhtoan = slthanhtoan;
    }
    ifstream v("invoices.txt");
    if (v >> slhd) {
        v.ignore(10000, '\n');
        if (slhd < 0 || slhd > MAX_INVOICES) slhd = 0;
        for (int i = 0; i < slhd; i++) {
            getline(v, hd[i].mahd); getline(v, hd[i].madh); getline(v, hd[i].mathanhtoan);
            getline(v, hd[i].makh); getline(v, hd[i].tenkh); getline(v, hd[i].ngaytao);
            v >> hd[i].tongtien; v.ignore(10000, '\n');
        }
        stthd = slhd;
    }
}

