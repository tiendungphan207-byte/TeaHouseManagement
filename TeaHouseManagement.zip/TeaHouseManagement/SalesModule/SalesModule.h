#ifndef SALES_MODULE_H
#define SALES_MODULE_H
#include "Models.h"

class SalesModule {
private:
    struct SPGioHang { 
        string masp, tensp; 
        int loaisp; 
        double sl; 
        long long giagoc; 
    };
    
    SPGioHang giohang[MAX_CART_ITEMS];     
    DonHang dh[MAX_ORDERS];           
    ThanhToan thanhtoan[MAX_PAYMENTS];       
    HoaDon hd[MAX_INVOICES];           
    
    int slgiohang, sldh, slthanhtoan, slhd; 
    int sttdh, sttsp, sttthanhtoan, stthd; 
    string makh, tenkh;                    

    int timdh(string ma);                
    long long totalgiohang();              
    string taoMa(string tiento, int &stt);  
    string laytg();                      
    void taohoadon(int id_DHang, int id_TToan); 
    void luudata();                        
    void docdata();                        

public:
    SalesModule();
    void taogiohang(string ma, string ten);   
    int themvaogiohang(string ma, string ten, int loai, double sl, long long gia); 
    int xoakhoigiohang(int vitri);            
    int capnhatsl(int vitri, double sl); 
    void hienthigiohang();                    
    string taodh();                      
    void hienthidh();                    
    void hienthidh(string ma);          
    void timtheokh(string maKH);        
    void timtheongay(string ngay);      
    int huydh(string ma);                
    int thanhtoandh(string ma, int phuongthuc);   
    void hienthithanhtoan();                    
    void hienthihoadon(string ma);            
    void doanhthutheongay(string ngay);         
    int layslspdh(string ma);        
    int layspdh(string ma, int vitri, ItemDonHang &sp); 
    int danhdautrukho(string ma);           
};
#endif