// UserModule.cpp - CAI DAT module tai khoan va phan quyen
#include <iostream>
#include <cstdlib>
#include "UserModule.h"
using namespace std;

string featureName[FEATURE_COUNT] = {
	"Xem thuc don", "Dat phong / dat ban", "Ban hang (order, thanh toan)",
	"Quan ly phong", "Quan ly kho tra", "Xem doanh thu", "Quan ly tai khoan"
};

// =============================================================== Account
Account::Account(){
	id = 0;
	locked = false;
	for(int i = 0; i < FEATURE_COUNT; i++) perm[i] = false;
}

Account::Account(int i, string nam, string pho, string ema, string use, string pas, string rol){
	id = i;
	fullName = nam;
	phone = pho;
	email = ema;
	username = use;
	password = pas;
	role = rol;
	locked = false;
	setDefaultPermissions();
}

// Quyen mac dinh theo vai tro
void Account::setDefaultPermissions(){
	for(int i = 0; i < FEATURE_COUNT; i++) perm[i] = false;
	perm[F_VIEW_MENU] = true;                 // ai cung xem duoc thuc don
	if(role == "Customer") perm[F_BOOKING] = true;
	if(role == "Artist")   perm[F_BOOKING] = true;
	if(role == "Staff"){
		perm[F_BOOKING] = true;
		perm[F_SELL] = true;
		perm[F_ROOM] = true;
	}
	if(role == "Owner"){
		for(int i = 0; i < FEATURE_COUNT; i++) perm[i] = true;
	}
}

bool Account::can(int feature){
	return !locked && perm[feature];
}

void Account::display(){
	cout << id << "\t" << username << "\t" << role << "\t" << fullName << "\t" << phone
	     << "\t" << (locked ? "BI KHOA" : "Hoat dong") << "\n";
}

// ============================================================ Ham nhap lieu
string inputLine(string prompt){
	string s;
	cout << prompt;
	getline(cin, s);
	return s;
}

int inputInt(string prompt){
	string s = inputLine(prompt);
	if(s.empty()) return -1;
	for(unsigned i = 0; i < s.size(); i++){
		if(s[i] < '0' || s[i] > '9') return -1;
	}
	return atoi(s.c_str());
}

bool isValidPhone(string s){
	if(s.size() < 8 || s.size() > 15) return false;
	for(unsigned i = 0; i < s.size(); i++){
		if(s[i] < '0' || s[i] > '9') return false;
	}
	return true;
}

bool isValidEmail(string s){
	size_t at = s.find('@');
	if(at == string::npos || at == 0) return false;
	size_t dot = s.find('.', at);
	return dot != string::npos && dot > at + 1 && dot < s.size() - 1;
}

// ============================================================== UserModule
UserModule::UserModule(){
	count = 0;
	nextId = 1;
	// Tai khoan Owner co san de co the dang nhap lan dau
	addAccount("Chu Phong Tra", "0900000000", "owner@teahouse.vn", "owner", "owner123", "Owner");
}

int UserModule::findByUsername(string username){
	for(int i = 0; i < count; i++){
		if(list[i].username == username) return i;
	}
	return -1;
}

int UserModule::findByPhone(string phone){
	for(int i = 0; i < count; i++){
		if(list[i].phone == phone) return i;
	}
	return -1;
}

int UserModule::findById(int id){
	for(int i = 0; i < count; i++){
		if(list[i].id == id) return i;
	}
	return -1;
}

// Kiem tra du lieu; tra ve "" neu hop le, nguoc lai tra ve noi dung loi
string UserModule::checkNewAccount(string nam, string pho, string ema, string use, string pas){
	if(nam.empty() || pho.empty() || ema.empty() || use.empty() || pas.empty())
		return "Khong duoc de trong thong tin bat buoc.";
	if(!isValidPhone(pho)) return "So dien thoai phai gom 8-15 chu so.";
	if(!isValidEmail(ema)) return "Email khong hop le.";
	if(use.find(' ') != string::npos) return "Ten dang nhap khong duoc co dau cach.";
	if(pas.size() < 6) return "Mat khau phai co it nhat 6 ky tu.";
	if(findByUsername(use) != -1) return "Ten dang nhap da ton tai.";
	if(findByPhone(pho) != -1) return "So dien thoai da duoc dang ky.";
	if(count >= MAX_ACCOUNTS) return "Danh sach tai khoan da day.";
	return "";
}

void UserModule::addAccount(string nam, string pho, string ema, string use, string pas, string rol){
	list[count] = Account(nextId, nam, pho, ema, use, pas, rol);
	count++;
	nextId++;
}

// 1. Dang ky tai khoan Customer (cho khach vang lai)
void UserModule::registerCustomer(){
	cout << "\n--- DANG KY TAI KHOAN ---\n";
	string nam = inputLine("Ho ten: ");
	string pho = inputLine("So dien thoai: ");
	string ema = inputLine("Email: ");
	string use = inputLine("Ten dang nhap: ");
	string pas = inputLine("Mat khau (>= 6 ky tu): ");
	string err = checkNewAccount(nam, pho, ema, use, pas);
	if(err != ""){
		cout << "Dang ky that bai: " << err << "\n";
		return;
	}
	addAccount(nam, pho, ema, use, pas, "Customer");
	cout << "Dang ky thanh cong! Ban co the dang nhap bang tai khoan '" << use << "'.\n";
}

// 2. Dang nhap: tra ve vi tri tai khoan trong mang, hoac -1 neu that bai
int UserModule::login(){
	cout << "\n--- DANG NHAP ---\n";
	string use = inputLine("Ten dang nhap: ");
	string pas = inputLine("Mat khau: ");
	int idx = findByUsername(use);
	if(idx == -1 || list[idx].password != pas){
		cout << "Dang nhap that bai: sai ten dang nhap hoac mat khau.\n";
		return -1;
	}
	if(list[idx].locked){
		cout << "Dang nhap that bai: tai khoan da bi khoa. Hay lien he Owner.\n";
		return -1;
	}
	cout << "Dang nhap thanh cong! Xin chao " << list[idx].fullName
	     << " (vai tro: " << list[idx].role << ").\n";
	return idx;
}

// 3a. Owner tao tai khoan Staff hoac Artist
void UserModule::createStaffAccount(string role){
	cout << "\n--- TAO TAI KHOAN " << role << " ---\n";
	string nam = inputLine("Ho ten: ");
	string pho = inputLine("So dien thoai: ");
	string ema = inputLine("Email: ");
	string use = inputLine("Ten dang nhap: ");
	string pas = inputLine("Mat khau (>= 6 ky tu): ");
	string err = checkNewAccount(nam, pho, ema, use, pas);
	if(err != ""){
		cout << "Tao tai khoan that bai: " << err << "\n";
		return;
	}
	addAccount(nam, pho, ema, use, pas, role);
	cout << "Da tao tai khoan " << role << " '" << use << "'.\n";
}

void UserModule::showAll(){
	cout << "\nID\tTai khoan\tVai tro\tHo ten\tSDT\tTrang thai\n";
	for(int i = 0; i < count; i++) list[i].display();
}

void UserModule::showOne(int idx){
	Account a = list[idx];
	cout << "\n--- THONG TIN TAI KHOAN ---\n";
	cout << "Ma           : " << a.id << "\n";
	cout << "Ho ten       : " << a.fullName << "\n";
	cout << "So dien thoai: " << a.phone << "\n";
	cout << "Email        : " << a.email << "\n";
	cout << "Ten dang nhap: " << a.username << "\n";
	cout << "Vai tro      : " << a.role << "\n";
	cout << "Trang thai   : " << (a.locked ? "Bi khoa" : "Hoat dong") << "\n";
}

// Cho Owner (sua bat ky tai khoan nao) va Customer (sua chinh minh)
void UserModule::editInfo(int idx){
	string nam = inputLine("Ho ten moi (Enter = giu nguyen): ");
	string pho = inputLine("So dien thoai moi (Enter = giu nguyen): ");
	string ema = inputLine("Email moi (Enter = giu nguyen): ");
	if(!pho.empty()){
		if(!isValidPhone(pho)){ cout << "So dien thoai khong hop le.\n"; return; }
		int other = findByPhone(pho);
		if(other != -1 && other != idx){ cout << "So dien thoai da co nguoi dung.\n"; return; }
	}
	if(!ema.empty() && !isValidEmail(ema)){ cout << "Email khong hop le.\n"; return; }
	if(!nam.empty()) list[idx].fullName = nam;
	if(!pho.empty()) list[idx].phone = pho;
	if(!ema.empty()) list[idx].email = ema;
	cout << "Da cap nhat thong tin.\n";
}

void UserModule::ownerEditAccount(){
	showAll();
	int idx = findById(inputInt("Nhap ma tai khoan can sua: "));
	if(idx == -1){ cout << "Khong tim thay tai khoan.\n"; return; }
	editInfo(idx);
}

void UserModule::changePassword(int idx){
	string oldPass = inputLine("Mat khau hien tai: ");
	if(oldPass != list[idx].password){ cout << "Mat khau hien tai khong dung.\n"; return; }
	string newPass = inputLine("Mat khau moi (>= 6 ky tu): ");
	if(newPass.size() < 6){ cout << "Mat khau moi qua ngan.\n"; return; }
	list[idx].password = newPass;
	cout << "Da doi mat khau.\n";
}

// 3b. Khoa / mo khoa
void UserModule::toggleLock(int currentIdx){
	showAll();
	int idx = findById(inputInt("Nhap ma tai khoan can khoa/mo khoa: "));
	if(idx == -1){ cout << "Khong tim thay tai khoan.\n"; return; }
	if(idx == currentIdx || list[idx].role == "Owner"){
		cout << "Khong the khoa tai khoan Owner.\n";
		return;
	}
	list[idx].locked = !list[idx].locked;
	cout << (list[idx].locked ? "Da khoa" : "Da mo khoa") << " tai khoan '" << list[idx].username << "'.\n";
}

// 3c + 4. Phan quyen cho nhan vien
void UserModule::setStaffPermission(){
	showAll();
	int idx = findById(inputInt("Nhap ma nhan vien can phan quyen: "));
	if(idx == -1){ cout << "Khong tim thay tai khoan.\n"; return; }
	if(list[idx].role != "Staff"){ cout << "Chi phan quyen duoc cho Staff.\n"; return; }
	showPermissions(idx);
	cout << "Chi co the cap/thu hoi: Quan ly kho tra (4), Xem doanh thu (5).\n";
	int f = inputInt("Chon chuc nang (4 hoac 5): ");
	if(f != F_INVENTORY && f != F_REVENUE){ cout << "Lua chon khong hop le.\n"; return; }
	list[idx].perm[f] = !list[idx].perm[f];
	cout << (list[idx].perm[f] ? "Da CAP quyen: " : "Da THU HOI quyen: ") << featureName[f] << "\n";
}

void UserModule::showPermissions(int idx){
	cout << "\nQuyen cua '" << list[idx].username << "' (" << list[idx].role << "):\n";
	for(int i = 0; i < FEATURE_COUNT; i++){
		cout << "  " << i << ". " << featureName[i] << " : "
		     << (list[idx].perm[i] ? "DUOC PHEP" : "khong duoc phep") << "\n";
	}
}

// 4. Kiem tra quyen truoc khi vao chuc nang (cac module khac se goi ham nay)
bool UserModule::checkAccess(int idx, int feature){
	if(idx == -1) return feature == F_VIEW_MENU;   // Guest chi xem thuc don
	if(list[idx].can(feature)) return true;
	cout << "[TU CHOI] Vai tro " << list[idx].role << " khong co quyen: "
	     << featureName[feature] << "\n";
	return false;
}
