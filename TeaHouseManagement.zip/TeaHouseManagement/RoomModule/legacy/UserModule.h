// UserModule.h - KHAI BAO module quan ly tai khoan va phan quyen
// Cac module khac (Phong, Kho, Thanh toan, Dat cho) chi can #include "UserModule.h"
#ifndef USERMODULE_H
#define USERMODULE_H

#include <string>
using namespace std;

const int MAX_ACCOUNTS  = 100;
const int FEATURE_COUNT = 7;

// Danh sach chuc nang cua phan mem (so thu tu = chi so trong mang quyen)
const int F_VIEW_MENU = 0;
const int F_BOOKING   = 1;
const int F_SELL      = 2;
const int F_ROOM      = 3;
const int F_INVENTORY = 4;
const int F_REVENUE   = 5;
const int F_ACCOUNT   = 6;
extern string featureName[FEATURE_COUNT];

// ---------------------------------------------------------------- Tai khoan
class Account{
	public:
		int id;
		string fullName, phone, email, username, password, role;   // role: Owner/Staff/Artist/Customer
		bool locked;
		bool perm[FEATURE_COUNT];   // perm[i] = true nghia la duoc dung chuc nang i

		Account();
		Account(int i, string nam, string pho, string ema, string use, string pas, string rol);
		void setDefaultPermissions();   // quyen mac dinh theo vai tro
		bool can(int feature);          // chua bi khoa va co quyen
		void display();                 // in 1 dong trong danh sach
};

// ------------------------------------------------------------ Ham nhap lieu
string inputLine(string prompt);
int    inputInt(string prompt);          // tra ve -1 neu nhap sai
bool   isValidPhone(string s);
bool   isValidEmail(string s);

// ------------------------------------------------------------- UserModule
class UserModule{
	public:
		Account list[MAX_ACCOUNTS];
		int count, nextId;

		UserModule();

		// Tim kiem (tra ve vi tri trong mang, -1 neu khong co)
		int findByUsername(string username);
		int findByPhone(string phone);
		int findById(int id);

		// Dang ky / tao tai khoan
		string checkNewAccount(string nam, string pho, string ema, string use, string pas);
		void   addAccount(string nam, string pho, string ema, string use, string pas, string rol);
		void   registerCustomer();
		void   createStaffAccount(string role);

		// Dang nhap
		int  login();

		// Hien thi
		void showAll();
		void showOne(int idx);
		void showPermissions(int idx);

		// Chinh sua
		void editInfo(int idx);
		void ownerEditAccount();
		void changePassword(int idx);

		// Quan tri (Owner)
		void toggleLock(int currentIdx);
		void setStaffPermission();

		// RBAC: cac module khac goi ham nay truoc khi cho nguoi dung vao chuc nang
		bool checkAccess(int idx, int feature);
};

#endif
