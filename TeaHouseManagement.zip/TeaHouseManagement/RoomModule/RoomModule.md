# RoomModule – Quản lý phòng và đặt phòng (Người 2)

> Phạm vi: phòng, giá thuê, đặt phòng, kiểm tra phòng trống, lịch đặt, tiền thuê phòng.
> **Không** quản lý tài khoản (việc của UserModule) và **không** trực tiếp xử lý tiền thanh toán (việc của Module 4).

## 1. Các file và thứ tự làm

| Thứ tự | File | Vai trò |
|---|---|---|
| 0 | `UserModule.h`, `UserModule.cpp` | Module của Người 1, **giữ nguyên, không sửa** |
| 1 | `RoomModule.h` | Khai báo: hằng số, class `Room`, `Booking`, `RoomModule`, hàm tiện ích |
| 2 | `RoomModule.cpp` | Cài đặt toàn bộ logic |
| 3 | `RoomMain.cpp` | `main` để chạy thử: menu theo vai trò + kiểm thử tự động |
| 4 | `RoomModule.md` | Tài liệu này |

Biên dịch và chạy:
```
g++ UserModule.cpp RoomModule.cpp RoomMain.cpp -o room_app
./room_app          (Windows: room_app.exe)
```
Ở màn hình chính chọn **9** để chạy kiểm thử tự động. Tài khoản có sẵn: `owner` / `owner123`.

## 2. Cách ghép với UserModule

`RoomModule` nhận con trỏ tới `UserModule` khi tạo:
```cpp
UserModule um;
RoomModule rm(&um);
int idx = um.login();           // idx = vị trí tài khoản, Guest = -1
rm.createBooking(idx, ...);     // RoomModule tự hỏi quyền qua um
```
Quyền dùng (do UserModule cấp sẵn, không phải sửa gì):

| Hành động | Quyền cần | Ai có |
|---|---|---|
| Xem phòng, giá, lịch trống | `F_VIEW_MENU` | Tất cả, kể cả Guest |
| Đặt phòng, xem lịch sử, hủy lịch của mình | `F_BOOKING` | Customer, Artist, Staff, Owner (Guest không) |
| Xem toàn bộ lịch, check-in, check-out, hủy lịch, đổi trạng thái phòng | `F_ROOM` | Staff, Owner |
| Thêm / sửa / xóa phòng, cài giá | vai trò **Owner** | Chỉ Owner |

Hàm `hasPermission(idx, feature)` dùng đúng quy tắc của `UserModule::checkAccess` (Guest chỉ xem; tài khoản bị khóa thì không có quyền) nhưng **không in thông báo**, để module tự trả lỗi bằng chuỗi.

**Lưu ý:** việc "chỉ Owner" dùng kiểm tra `role == "Owner"` vì UserModule chưa có quyền riêng cho cấu hình phòng. Nếu muốn tách ra, thêm `F_ROOM_ADMIN` vào `UserModule.h` rồi đổi `isOwner()`.

## 3. Đối tượng dữ liệu

**Room** (phòng)

| Thuộc tính | Ý nghĩa |
|---|---|
| id | Mã phòng, duy nhất, tự tăng |
| name | Tên phòng (Phòng Trúc, Phòng Sen…), không trùng |
| capacity | Sức chứa (1–100) |
| pricePerHour | Giá thuê theo giờ, **Owner cài cho từng phòng** (1 – 20.000.000) |
| type | `Thuong` / `Cao cap` / `VIP` / `Rieng` |
| amenities | Tiện ích: bàn trà, ấm chén, điều hòa… |
| status | `R_FREE` Trống, `R_IN_USE` Đang sử dụng, `R_MAINTENANCE` Bảo trì |

**Booking** (đặt phòng)

| Thuộc tính | Ý nghĩa |
|---|---|
| id | **Mã đặt phòng** (đây là mã chuyển sang Module 4) |
| roomId, customerId | Phòng nào, tài khoản nào đặt (`Account.id` của UserModule) |
| date, startMin, endMin | Ngày (dạng `yyyymmdd`), giờ bắt đầu/kết thúc tính bằng phút (14:00 = 840) |
| guests | Số khách |
| status | `B_BOOKED` Đã đặt → `B_CHECKED_IN` Đang dùng → `B_DONE` Đã trả; hoặc `B_CANCELLED` Đã hủy |
| rate | Giá/giờ **chốt lúc đặt** (Owner đổi giá sau không ảnh hưởng lịch cũ) |
| fee | Tiền thuê: dự kiến lúc đặt, thực tế sau khi trả phòng |
| actualEndMin | Giờ trả phòng thực tế |

Dữ liệu mẫu có sẵn: Phòng Trúc 500.000 (thường), Phòng Sen 800.000 (cao cấp), Phòng Mai VIP 2.000.000. Đây chỉ là dữ liệu khởi tạo, Owner đổi được bất cứ lúc nào.

## 4. Chức năng, đầu vào, đầu ra

Các hàm xử lý trả về **chuỗi lỗi**: `""` nghĩa là thành công, ngược lại là nội dung lỗi để in ra (cùng kiểu với `checkNewAccount` của UserModule).

| Chức năng | Hàm | Đầu vào | Đầu ra |
|---|---|---|---|
| Thêm phòng (Owner) | `addRoom` | idx, tên, sức chứa, giá, loại, tiện ích | `""` + mã phòng mới |
| Sửa phòng (Owner) | `editRoom` | idx, mã phòng, tên, sức chứa, loại, tiện ích | `""` hoặc lỗi |
| Cài giá (Owner) | `setPrice` | idx, mã phòng, giá | `""` hoặc lỗi |
| Xóa phòng (Owner) | `deleteRoom` | idx, mã phòng | `""` hoặc lỗi |
| Đổi trạng thái (Staff/Owner) | `setRoomStatus` | idx, mã phòng, Trống hoặc Bảo trì | `""` hoặc lỗi |
| Xem phòng + giá | `showRooms` | không | Bảng phòng |
| Xem lịch phòng trống | `showSchedule` | mã phòng, ngày | Các khung giờ ĐÃ ĐẶT và TRỐNG |
| Kiểm tra yêu cầu | `checkRequest` | phòng, ngày, giờ bắt đầu/kết thúc, số khách | `""` nếu đặt được |
| Đặt phòng (Customer) | `createBooking` | idx, phòng, ngày, giờ, số khách | `""` + mã đặt phòng |
| Xem lịch sử của tôi | `showMyBookings` | idx | Chỉ lịch của chính tài khoản đó |
| Xem tất cả lịch (Staff) | `showAllBookings` | ngày (0 = tất cả) | Danh sách lịch |
| Hủy (Customer) | `cancelByCustomer` | idx, mã đặt phòng | `""` hoặc lỗi |
| Hủy (Staff) | `cancelByStaff` | idx, mã đặt phòng | `""` hoặc lỗi |
| Khách đến, dùng phòng | `checkIn` | idx, mã đặt phòng | `""`; phòng → Đang sử dụng |
| Khách trả phòng | `checkOut` | idx, mã đặt phòng, giờ thực tế (-1 = bây giờ) | `""` + tiền thuê; phòng → Trống |
| Chuyển sang thanh toán | `getPaymentInfo` | mã đặt phòng | `""` + số tiền |

## 5. Quy tắc nghiệp vụ và ngoại lệ

**Tính tiền:** `tiền = số giờ × giá/giờ`, thời gian lẻ **làm tròn lên giờ**, tối thiểu 1 giờ.
Ví dụ: VIP 1.000.000 đ/giờ thuê 2 giờ = 2.000.000 đ. Thuê 1 giờ 10 phút với giá 500.000 đ/giờ = 2 giờ = 1.000.000 đ.
Tính theo giờ **thực tế** lúc trả phòng (ở lúc đặt chỉ là tiền dự kiến).

**Đặt phòng bị từ chối khi:**
- Chưa đăng nhập (Guest) hoặc tài khoản không có quyền / bị khóa.
- Phòng không tồn tại hoặc đang **bảo trì**.
- Số khách < 1 hoặc **vượt sức chứa**.
- Ngày trong quá khứ, hoặc hôm nay mà giờ bắt đầu đã qua.
- Ngoài giờ mở cửa (08:00–22:00) hoặc giờ kết thúc ≤ giờ bắt đầu.
- **Trùng khung giờ** với lịch đang hiệu lực của cùng phòng, cùng ngày. Khung liền kề (kết thúc 16:00, bắt đầu 16:00) được phép.

**Hủy:**
- Customer chỉ hủy lịch **của mình**, trạng thái "Đã đặt", và **trước giờ bắt đầu ít nhất 2 giờ**. Sát giờ phải nhờ nhân viên.
- Staff/Owner hủy được không bị ràng buộc thời gian.
- Giờ của lịch đã hủy được đặt lại.

**Check-in / check-out:**
- Check-in chỉ đúng ngày đặt, phòng không bảo trì, không có khách khác đang dùng.
- Không check-in hai lần, không check-out nếu chưa check-in.

**Phòng:**
- Không xóa phòng đang có lịch "Đã đặt" hoặc "Đang dùng".
- Không giảm sức chứa thấp hơn số khách của lịch đang hiệu lực.
- Không bảo trì phòng đang có khách. Tên phòng không trùng.
- Đổi giá không ảnh hưởng lịch đã đặt (giá chốt trong `Booking.rate`).

**Giới hạn của bản đầu:**
- Mỗi lịch trong **một ngày** (không thuê qua đêm).
- Dữ liệu lưu trong bộ nhớ, tắt chương trình là mất.
- Khách trả phòng muộn quá giờ kết thúc vẫn được tính thêm tiền theo giờ thực tế, nhưng chương trình không kiểm tra va chạm với lịch kế tiếp.
- "Xác nhận khách đến" và "ghi nhận khách sử dụng phòng" gộp thành một thao tác `checkIn`.

## 6. Phối hợp với các module khác

| Module | RoomModule cung cấp / cần |
|---|---|
| **UserModule** (Người 1) | Cần: `um.list[idx].can(...)`, `Account.id`, `role`. RoomModule chỉ **đọc**, không sửa tài khoản |
| **Thanh toán** (Module 4) | Cung cấp: `getPaymentInfo(bookingId, amount)` → **mã đặt phòng + số tiền**. Module 4 tự thu tiền; RoomModule không động vào tiền |
| **Kho trà / Bán hàng** | Có thể dùng `Booking.id` và `roomId` để gắn đơn gọi đồ vào phòng đang dùng (`R_IN_USE`) |
| **Nghệ nhân** (nếu có) | Có thể đọc lịch phòng qua `showSchedule` hoặc mảng `books` để xếp lịch phục vụ |

Ghép chung một chương trình: tạo **một** `UserModule um` và **một** `RoomModule rm(&um)` trong `main` chung, truyền `idx` sau khi đăng nhập cho mọi hàm.

## 7. Giả lập thời gian để kiểm thử

`rm.setNow(20261110, 9 * 60)` đặt "bây giờ" là 10/11/2026 lúc 09:00. Mặc định lấy giờ máy. Trong menu Staff/Owner có mục **9. Đặt giờ hệ thống** để demo luật hủy trước 2 giờ và check-in theo ngày.

## 8. Kiểm thử

Chạy `room_app`, chọn **9**: 72 kiểm tra tự động, chia 8 nhóm.

| Nhóm | Ví dụ kiểm tra |
|---|---|
| 1. Phòng và giá | Owner thêm phòng; Customer/Staff bị từ chối; trùng tên, sức chứa 0, giá 0, loại sai bị từ chối; Owner đổi giá |
| 2. Phân quyền | Guest không đặt được, chỉ xem; Customer không check-in; Staff quản lý phòng được |
| 3. Đặt phòng, tính tiền | VIP 2 giờ × 1.000.000 = 2.000.000; 1h10 làm tròn 2 giờ |
| 4. Phòng trống | Trùng giờ và trùng một phần bị từ chối; liền kề và khác ngày được phép; vượt sức chứa; ngoài giờ mở cửa; quá khứ; phòng bảo trì |
| 5. Hủy lịch | Hủy khi còn < 2 giờ bị từ chối; Staff hủy được; không hủy lịch người khác |
| 6. Check-in/out, thanh toán | Đổi trạng thái phòng; không xóa/bảo trì phòng đang có khách; tính tiền theo giờ thực tế; xuất mã đặt phòng + số tiền |
| 7. Khác ngày / bảo trì / khóa | Check-in sai ngày; phòng bảo trì; Staff bị khóa không làm được gì |
| 8. Giá, sửa, xóa, lịch sử | Đổi giá không ảnh hưởng lịch cũ; không giảm sức chứa dưới số khách đã đặt; không xóa phòng còn lịch; mỗi khách có lịch sử riêng; ngày nhuận, định dạng giờ, tiền |
