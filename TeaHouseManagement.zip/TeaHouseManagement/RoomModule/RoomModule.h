// RoomModule.h - KHAI BAO module quan ly phong va dat phong (Nguoi 2)
// Ghep voi UserModule: moi chuc nang deu hoi quyen qua UserModule truoc khi lam.
#ifndef ROOMMODULE_H
#define ROOMMODULE_H

#include <string>
#include "UserModule.h"
using namespace std;

const int MAX_ROOMS    = 50;
const int MAX_BOOKINGS = 500;

// Trang thai phong
const int R_FREE        = 0;   // Trong
const int R_IN_USE      = 1;   // Dang su dung
const int R_MAINTENANCE = 2;   // Bao tri

// Trang thai dat phong
const int B_BOOKED    = 0;     // Da dat, cho khach den
const int B_CHECKED_IN = 1;    // Khach dang su dung phong
const int B_DONE      = 2;     // Da tra phong
const int B_CANCELLED = 3;     // Da huy

// Quy dinh cua phong tra (doi o day neu quan doi quy dinh)
const int OPEN_MIN          = 8 * 60;    // Mo cua 08:00
const int CLOSE_MIN         = 22 * 60;   // Dong cua 22:00
const int CANCEL_BEFORE_MIN = 120;       // Khach chi duoc huy truoc gio bat dau it nhat 2 gio
const long long MAX_PRICE   = 20000000;  // Gia thue toi da / gio (chong nhap nham)

// ------------------------------------------------------------------ Phong
class Room{
	public:
		int id;
		string name;
		int capacity;            // so nguoi toi da
		long long pricePerHour;  // do Owner cai dat cho tung phong
		string type;             // Thuong / Cao cap / VIP / Rieng
		string amenities;        // ban tra, am chen, dieu hoa...
		int status;              // R_FREE, R_IN_USE, R_MAINTENANCE

		Room();
		Room(int i, string nam, int cap, long long price, string typ, string ame);
		void display();
};

// -------------------------------------------------------------- Dat phong
class Booking{
	public:
		int id;
		int roomId;
		int customerId;          // = Account.id cua nguoi dat (lay tu UserModule)
		int date;                // dang yyyymmdd, vi du 20261110
		int startMin, endMin;    // gio theo phut trong ngay (14:00 = 840)
		int guests;
		int status;              // B_BOOKED, B_CHECKED_IN, B_DONE, B_CANCELLED
		int actualEndMin;        // gio tra phong thuc te (-1 neu chua tra)
		long long rate;          // gia/gio CHOT luc dat (Owner doi gia sau khong anh huong)
		long long fee;           // tien thue phong (du kien, sau khi tra phong la thuc te)

		Booking();
		void display();
};

// ---------------------------------------------------- Ham tien ich (gio, ngay, tien)
bool   parseDate(string s, int &out);          // "2026-11-10" -> 20261110
bool   parseTime(string s, int &out);          // "14:30" -> 870
string formatDate(int d);
string formatTime(int minutes);
string formatMoney(long long v);               // 1000000 -> "1.000.000"
string roomStatusName(int s);
string bookingStatusName(int s);
bool   isValidRoomType(string t);
long long calcRoomFee(long long ratePerHour, int minutes);   // lam tron LEN gio

// -------------------------------------------------------------- RoomModule
class RoomModule{
	public:
		UserModule *users;       // module tai khoan (de hoi quyen)
		Room list[MAX_ROOMS];
		int roomCount, nextRoomId;
		Booking books[MAX_BOOKINGS];
		int bookCount, nextBookId;
		int today, nowMin;       // "bay gio" cua he thong (co the dat tay de kiem thu)

		RoomModule(UserModule *u);
		void setNow(int date, int minutes);

		// Quyen (cung quy tac voi UserModule::checkAccess nhung khong in thong bao)
		bool hasPermission(int idx, int feature);
		bool isOwner(int idx);

		// Tim kiem (tra ve vi tri trong mang, -1 neu khong co)
		int findRoom(int roomId);
		int findBooking(int bookingId);
		int countActiveBookings(int roomId);        // dat phong dang BOOKED hoac CHECKED_IN
		int countBookingsOf(int customerId);

		// 1+2. Quan ly phong va gia (Owner). Ham tra ve "" neu thanh cong, nguoc lai la noi dung loi
		string addRoom(int idx, string name, int capacity, long long price, string type, string amenities, int &newId);
		string editRoom(int idx, int roomId, string name, int capacity, string type, string amenities);
		string setPrice(int idx, int roomId, long long price);
		string deleteRoom(int idx, int roomId);
		string setRoomStatus(int idx, int roomId, int status);   // Owner hoac Staff

		// Xem thong tin (Guest cung xem duoc)
		void showRooms();
		void showSchedule(int roomId, int date);

		// 3+4. Kiem tra phong trong va dat phong (Customer)
		string checkRequest(int roomId, int date, int startMin, int endMin, int guests, int ignoreBookingId);
		string createBooking(int idx, int roomId, int date, int startMin, int endMin, int guests, int &newId);
		void   showBooking(int bookingId);
		void   showMyBookings(int idx);

		// 5. Quan ly lich dat (Staff)
		void   showAllBookings(int date);                // date = 0: tat ca
		string cancelByCustomer(int idx, int bookingId);
		string cancelByStaff(int idx, int bookingId);
		string checkIn(int idx, int bookingId);
		string checkOut(int idx, int bookingId, int actualEndMin, long long &fee);

		// 6 + dau ra cho Module thanh toan: ma dat phong va so tien
		string getPaymentInfo(int bookingId, long long &amount);
};

#endif
