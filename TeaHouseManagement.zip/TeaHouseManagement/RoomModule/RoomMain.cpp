// RoomMain.cpp - main de kiem thu RoomModule ghep voi UserModule
// Bien dich: g++ UserModule.cpp RoomModule.cpp RoomMain.cpp -o room_app
//  - Chay binh thuong : man hinh Guest -> dang nhap -> menu theo vai tro
//  - Chon 9 o man hinh chinh: chay kiem thu tu dong
#include <iostream>
#include <cstdlib>
#include "UserModule.h"
#include "RoomModule.h"
using namespace std;

// ------------------------------------------------------------ Nhap lieu
long long inputMoney(string prompt){
	string s = inputLine(prompt);
	if(s.empty()) return -1;
	for(unsigned i = 0; i < s.size(); i++){
		if(s[i] < '0' || s[i] > '9') return -1;
	}
	return atoll(s.c_str());
}

int inputDate(string prompt){
	int d;
	string s = inputLine(prompt);
	if(!parseDate(s, d)) return -1;
	return d;
}

int inputTime(string prompt){
	int t;
	string s = inputLine(prompt);
	if(!parseTime(s, t)) return -1;
	return t;
}

void say(string err, string okMessage){
	if(err == "") cout << okMessage << "\n";
	else cout << "Khong thuc hien duoc: " << err << "\n";
}

// ------------------------------------------------- Chuc nang chung (UI)
void uiShowSchedule(RoomModule &rm){
	rm.showRooms();
	int id = inputInt("Ma phong: ");
	int date = inputDate("Ngay xem (YYYY-MM-DD): ");
	if(date == -1){ cout << "Ngay khong hop le.\n"; return; }
	rm.showSchedule(id, date);
}

void uiBook(RoomModule &rm, int idx){
	rm.showRooms();
	int roomId = inputInt("Ma phong muon dat: ");
	int date = inputDate("Ngay thue (YYYY-MM-DD): ");
	int st = inputTime("Gio bat dau (HH:MM): ");
	int en = inputTime("Gio ket thuc (HH:MM): ");
	int guests = inputInt("So khach: ");
	if(date == -1 || st == -1 || en == -1){ cout << "Ngay hoac gio khong dung dinh dang.\n"; return; }
	int newId = 0;
	string err = rm.createBooking(idx, roomId, date, st, en, guests, newId);
	if(err != ""){ cout << "Dat phong that bai: " << err << "\n"; return; }
	cout << "Dat phong thanh cong! Ma dat phong cua ban: " << newId << "\n";
	rm.showBooking(newId);
}

void uiPaymentInfo(RoomModule &rm){
	int id = inputInt("Ma dat phong: ");
	long long amount = 0;
	string err = rm.getPaymentInfo(id, amount);
	if(err != "") cout << err << "\n";
	else cout << "Chuyen sang Module thanh toan -> Ma dat phong: " << id << ", so tien: " << formatMoney(amount) << " VND\n";
}

void uiCheckOut(RoomModule &rm, int idx){
	int id = inputInt("Ma dat phong tra phong: ");
	string s = inputLine("Gio tra phong thuc te (HH:MM, Enter = bay gio): ");
	int t = -1;
	if(s != "" && !parseTime(s, t)){ cout << "Gio khong hop le.\n"; return; }
	long long fee = 0;
	string err = rm.checkOut(idx, id, t, fee);
	if(err != "") cout << "Khong thuc hien duoc: " << err << "\n";
	else cout << "Da tra phong. Tien thue phong: " << formatMoney(fee) << " VND (ma dat phong " << id << ")\n";
}

void uiSetNow(RoomModule &rm){
	int d = inputDate("Ngay he thong (YYYY-MM-DD): ");
	int t = inputTime("Gio he thong (HH:MM): ");
	if(d == -1 || t == -1){ cout << "Khong hop le.\n"; return; }
	rm.setNow(d, t);
	cout << "Da dat gio he thong: " << formatDate(d) << " " << formatTime(t) << "\n";
}

void uiAddRoom(RoomModule &rm, int idx){
	string name = inputLine("Ten phong: ");
	int cap = inputInt("Suc chua (nguoi): ");
	long long price = inputMoney("Gia thue (VND/gio): ");
	string type = inputLine("Loai phong (Thuong / Cao cap / VIP / Rieng): ");
	string ame = inputLine("Tien ich: ");
	int newId = 0;
	say(rm.addRoom(idx, name, cap, price, type, ame, newId), "Da them phong.");
}

void uiEditRoom(RoomModule &rm, int idx){
	rm.showRooms();
	int id = inputInt("Ma phong can sua: ");
	string name = inputLine("Ten moi: ");
	int cap = inputInt("Suc chua moi: ");
	string type = inputLine("Loai phong moi: ");
	string ame = inputLine("Tien ich moi: ");
	say(rm.editRoom(idx, id, name, cap, type, ame), "Da cap nhat phong.");
}

void uiSetPrice(RoomModule &rm, int idx){
	rm.showRooms();
	int id = inputInt("Ma phong: ");
	long long price = inputMoney("Gia thue moi (VND/gio): ");
	say(rm.setPrice(idx, id, price), "Da cap nhat gia thue.");
}

void uiDeleteRoom(RoomModule &rm, int idx){
	rm.showRooms();
	int id = inputInt("Ma phong can xoa: ");
	say(rm.deleteRoom(idx, id), "Da xoa phong.");
}

void uiSetStatus(RoomModule &rm, int idx){
	rm.showRooms();
	int id = inputInt("Ma phong: ");
	int s = inputInt("Trang thai moi (0 = Trong, 2 = Bao tri): ");
	say(rm.setRoomStatus(idx, id, s), "Da cap nhat trang thai phong.");
}

// ------------------------------------------------------------------ Menu
void customerMenu(RoomModule &rm, int idx){
	int c;
	do{
		cout << "\n===== MENU KHACH (dat phong) =====\n"
		     << "1. Xem danh sach phong va gia\n2. Xem lich phong trong\n3. Dat phong\n"
		     << "4. Lich su dat phong cua toi\n5. Huy lich dat\n6. Xem tien thue (ma dat phong)\n0. Dang xuat\n";
		c = inputInt("Chon: ");
		switch(c){
			case 1: rm.showRooms(); break;
			case 2: uiShowSchedule(rm); break;
			case 3: uiBook(rm, idx); break;
			case 4: rm.showMyBookings(idx); break;
			case 5: {
				int id = inputInt("Ma dat phong can huy: ");
				say(rm.cancelByCustomer(idx, id), "Da huy lich dat.");
				break;
			}
			case 6: uiPaymentInfo(rm); break;
			case 0: break;
			default: cout << "Lua chon khong hop le.\n";
		}
	}while(c != 0);
}

void staffMenu(RoomModule &rm, int idx, bool isOwner){
	int c;
	do{
		cout << "\n===== MENU " << (isOwner ? "OWNER" : "STAFF") << " (quan ly phong) =====\n"
		     << "1. Xem danh sach phong\n2. Xem lich phong\n3. Xem tat ca lich dat\n"
		     << "4. Khach den (check-in)\n5. Khach tra phong (check-out)\n6. Huy lich dat\n"
		     << "7. Doi trang thai phong (Trong / Bao tri)\n8. Xem tien thue (ma dat phong)\n"
		     << "9. Dat gio he thong (de demo)\n";
		if(isOwner) cout << "10. Them phong\n11. Sua phong\n12. Cai dat gia thue\n13. Xoa phong\n";
		cout << "0. Dang xuat\n";
		c = inputInt("Chon: ");
		switch(c){
			case 1: rm.showRooms(); break;
			case 2: uiShowSchedule(rm); break;
			case 3: rm.showAllBookings(0); break;
			case 4: {
				int id = inputInt("Ma dat phong: ");
				say(rm.checkIn(idx, id), "Da xac nhan khach den. Phong chuyen sang 'Dang su dung'.");
				break;
			}
			case 5: uiCheckOut(rm, idx); break;
			case 6: {
				int id = inputInt("Ma dat phong can huy: ");
				say(rm.cancelByStaff(idx, id), "Da huy lich dat.");
				break;
			}
			case 7: uiSetStatus(rm, idx); break;
			case 8: uiPaymentInfo(rm); break;
			case 9: uiSetNow(rm); break;
			case 10: if(isOwner) uiAddRoom(rm, idx); else cout << "Lua chon khong hop le.\n"; break;
			case 11: if(isOwner) uiEditRoom(rm, idx); else cout << "Lua chon khong hop le.\n"; break;
			case 12: if(isOwner) uiSetPrice(rm, idx); else cout << "Lua chon khong hop le.\n"; break;
			case 13: if(isOwner) uiDeleteRoom(rm, idx); else cout << "Lua chon khong hop le.\n"; break;
			case 0: break;
			default: cout << "Lua chon khong hop le.\n";
		}
	}while(c != 0);
}

// Artist chi co quyen dat/xem lich nen dung menu khach
void goToMenu(RoomModule &rm, UserModule &um, int idx){
	string role = um.list[idx].role;
	if(role == "Owner") staffMenu(rm, idx, true);
	else if(role == "Staff") staffMenu(rm, idx, false);
	else customerMenu(rm, idx);
	cout << "\nDa dang xuat. Quay ve man hinh chinh.\n";
}

// ======================================================== Kiem thu tu dong
int passed = 0, failed = 0;

void check(bool condition, string name){
	if(condition){ passed++; cout << "  [OK]   " << name << "\n"; }
	else { failed++; cout << "  [LOI]  " << name << "\n"; }
}

void runTests(){
	cout << "\n===== KIEM THU TU DONG RoomModule =====\n";
	passed = 0; failed = 0;
	UserModule um;
	RoomModule rm(&um);
	rm.setNow(20261110, 9 * 60);   // Gia lap: 10/11/2026 luc 09:00

	// Tao tai khoan thu (dung ham cua UserModule)
	um.addAccount("Khach A", "0911000001", "a@x.com", "khachA", "123456", "Customer");
	um.addAccount("Khach B", "0911000002", "b@x.com", "khachB", "123456", "Customer");
	um.addAccount("Nhan vien", "0911000003", "n@x.com", "nv1", "123456", "Staff");
	um.addAccount("Nghe nhan", "0911000004", "h@x.com", "art1", "123456", "Artist");
	int owner = um.findByUsername("owner");
	int a = um.findByUsername("khachA");
	int b = um.findByUsername("khachB");
	int staff = um.findByUsername("nv1");
	int artist = um.findByUsername("art1");
	int guest = -1;
	int id = 0;
	long long fee = 0;

	cout << "\n[1] Quan ly phong va gia\n";
	check(rm.roomCount == 3 && rm.list[0].pricePerHour == 500000, "Du lieu mau: phong thuong 500.000 VND/gio");
	check(rm.addRoom(owner, "Phong Lan", 4, 700000, "Cao cap", "Ban tra", id) == "", "Owner them phong moi");
	check(rm.addRoom(a, "Phong X", 4, 700000, "Cao cap", "", id) != "", "Customer khong duoc them phong");
	check(rm.addRoom(staff, "Phong X", 4, 700000, "Cao cap", "", id) != "", "Staff khong duoc them phong");
	check(rm.addRoom(owner, "Phong Lan", 4, 700000, "Cao cap", "", id) != "", "Trung ten phong bi tu choi");
	check(rm.addRoom(owner, "Phong Y", 0, 700000, "VIP", "", id) != "", "Suc chua 0 bi tu choi");
	check(rm.addRoom(owner, "Phong Y", 4, 0, "VIP", "", id) != "", "Gia 0 bi tu choi");
	check(rm.addRoom(owner, "Phong Y", 4, 700000, "Khac", "", id) != "", "Loai phong sai bi tu choi");
	check(rm.setPrice(owner, 3, 1000000) == "" && rm.list[2].pricePerHour == 1000000, "Owner doi gia phong VIP = 1.000.000");
	check(rm.setPrice(staff, 3, 1) != "", "Staff khong duoc doi gia");
	check(rm.editRoom(owner, 1, "Phong Truc Xanh", 6, "Thuong", "Ban tra") == "", "Owner sua ten phong");
	check(rm.editRoom(owner, 1, "Phong Sen", 6, "Thuong", "") != "", "Sua trung ten phong khac bi tu choi");

	cout << "\n[2] Phan quyen voi UserModule\n";
	check(rm.createBooking(guest, 1, 20261110, 600, 720, 2, id) != "", "Guest khong duoc dat phong (can dang nhap)");
	check(rm.hasPermission(guest, F_VIEW_MENU) && !rm.hasPermission(guest, F_ROOM), "Guest chi xem, khong quan ly phong");
	check(!rm.hasPermission(a, F_ROOM), "Customer khong co quyen quan ly phong");
	check(rm.hasPermission(staff, F_ROOM), "Staff co quyen quan ly phong");
	check(rm.checkIn(a, 1) != "", "Customer khong duoc check-in");

	cout << "\n[3] Dat phong va tinh tien\n";
	// Phong VIP (ma 3) gia 1.000.000, thue 2 gio -> 2.000.000
	check(rm.createBooking(a, 3, 20261110, 14 * 60, 16 * 60, 5, id) == "" && id == 1, "Khach A dat VIP 14:00-16:00");
	check(rm.books[rm.findBooking(1)].fee == 2000000, "Tien thue 2 gio x 1.000.000 = 2.000.000");
	check(rm.createBooking(a, 1, 20261110, 10 * 60, 10 * 60 + 70, 2, id) == "" , "Dat 1h10 phut phong thuong");
	check(rm.books[rm.findBooking(id)].fee == 1000000, "1h10 lam tron len 2 gio = 2 x 500.000");

	cout << "\n[4] Kiem tra phong trong\n";
	check(rm.createBooking(b, 3, 20261110, 15 * 60, 17 * 60, 2, id) != "", "Trung gio (15:00-17:00 vs 14:00-16:00) bi tu choi");
	check(rm.createBooking(b, 3, 20261110, 13 * 60, 15 * 60, 2, id) != "", "Trung mot phan (13:00-15:00) bi tu choi");
	check(rm.createBooking(b, 3, 20261110, 16 * 60, 18 * 60, 2, id) == "", "Lien ke (16:00-18:00) duoc phep");
	check(rm.createBooking(b, 3, 20261111, 14 * 60, 16 * 60, 2, id) == "", "Cung gio nhung khac ngay duoc phep");
	check(rm.createBooking(b, 3, 20261112, 14 * 60, 16 * 60, 13, id) != "", "So khach vuot suc chua bi tu choi");
	check(rm.createBooking(b, 3, 20261112, 14 * 60, 16 * 60, 0, id) != "", "So khach = 0 bi tu choi");
	check(rm.createBooking(b, 3, 20261112, 7 * 60, 9 * 60, 2, id) != "", "Truoc gio mo cua bi tu choi");
	check(rm.createBooking(b, 3, 20261112, 21 * 60, 23 * 60, 2, id) != "", "Sau gio dong cua bi tu choi");
	check(rm.createBooking(b, 3, 20261112, 15 * 60, 14 * 60, 2, id) != "", "Gio ket thuc <= gio bat dau bi tu choi");
	check(rm.createBooking(b, 3, 20261109, 14 * 60, 16 * 60, 2, id) != "", "Dat ngay trong qua khu bi tu choi");
	check(rm.createBooking(b, 3, 20261110, 8 * 60, 8 * 60 + 30, 2, id) != "", "Gio bat dau da qua (hom nay) bi tu choi");
	check(rm.createBooking(b, 99, 20261112, 14 * 60, 16 * 60, 2, id) != "", "Phong khong ton tai bi tu choi");
	check(rm.setRoomStatus(staff, 2, R_MAINTENANCE) == "", "Staff dat phong Sen sang Bao tri");
	check(rm.createBooking(b, 2, 20261112, 14 * 60, 16 * 60, 2, id) != "", "Phong bao tri khong nhan dat");
	check(rm.setRoomStatus(staff, 2, R_FREE) == "", "Staff dua phong Sen ve Trong");

	cout << "\n[5] Huy lich\n";
	check(rm.createBooking(b, 2, 20261110, 10 * 60 + 30, 11 * 60 + 30, 2, id) == "", "Khach B dat phong Sen 10:30 (con 1h30 nua)");
	int soonId = id;
	check(rm.cancelByCustomer(b, soonId) != "", "Huy khi con < 2 gio bi tu choi");
	check(rm.cancelByCustomer(a, 1) == "", "Khach A huy lich VIP 14:00 (con 5 gio)");
	check(rm.cancelByCustomer(b, 1) != "", "Khach B khong huy duoc lich da huy");
	check(rm.cancelByCustomer(b, 2) != "", "Khach B khong huy duoc lich cua khach A");
	check(rm.cancelByStaff(staff, soonId) == "", "Staff huy duoc lich con < 2 gio");
	check(rm.createBooking(b, 3, 20261110, 14 * 60, 16 * 60, 2, id) == "", "Gio cua lich da huy duoc dat lai");

	cout << "\n[6] Check-in, check-out, thanh toan\n";
	rm.setNow(20261110, 10 * 60);   // 10:00
	int idA = 2;                    // lich 10:00-11:10 phong Truc cua khach A
	check(rm.checkIn(staff, idA) == "", "Staff xac nhan khach den (check-in)");
	check(rm.list[0].status == R_IN_USE, "Phong chuyen sang 'Dang su dung'");
	check(rm.setRoomStatus(staff, 1, R_MAINTENANCE) != "", "Khong dat bao tri khi dang co khach");
	check(rm.deleteRoom(owner, 1) != "", "Khong xoa phong dang co lich hoat dong");
	check(rm.checkIn(staff, idA) != "", "Check-in lan 2 bi tu choi");
	rm.setNow(20261110, 11 * 60 + 5);   // 11:05
	check(rm.checkOut(a, idA, -1, fee) != "", "Customer khong duoc check-out");
	check(rm.checkOut(staff, idA, -1, fee) == "" && fee == 1000000, "Tra phong 11:05 (1h05) -> tinh 2 gio = 1.000.000");
	check(rm.list[0].status == R_FREE, "Phong tro lai 'Trong'");
	long long amount = 0;
	check(rm.getPaymentInfo(idA, amount) == "" && amount == 1000000, "Xuat ma dat phong + so tien cho Module thanh toan");
	check(rm.getPaymentInfo(1, amount) != "", "Lich da huy khong co khoan thanh toan");
	check(rm.checkOut(staff, idA, -1, fee) != "", "Tra phong 2 lan bi tu choi");

	cout << "\n[7] Check-in khac ngay / bao tri\n";
	check(rm.createBooking(a, 1, 20261111, 10 * 60, 12 * 60, 2, id) == "", "Khach A dat phong ngay mai");
	check(rm.checkIn(staff, id) != "", "Check-in sai ngay bi tu choi");
	rm.setRoomStatus(staff, 1, R_MAINTENANCE);
	rm.setNow(20261111, 10 * 60);
	check(rm.checkIn(staff, id) != "", "Check-in phong dang bao tri bi tu choi");
	rm.setRoomStatus(staff, 1, R_FREE);
	um.list[staff].locked = true;
	check(rm.checkIn(staff, id) != "", "Staff bi khoa tai khoan khong lam duoc gi");
	um.list[staff].locked = false;
	check(rm.checkIn(staff, id) == "", "Mo khoa xong thi check-in duoc");

	cout << "\n[8] Doi gia, sua phong, xoa phong, lich su\n";
	rm.setNow(20261110, 9 * 60);
	check(rm.createBooking(b, 3, 20261113, 9 * 60, 10 * 60, 2, id) == "", "Khach B dat VIP luc gia 1.000.000");
	int priceId = id;
	rm.setPrice(owner, 3, 1500000);
	check(rm.books[rm.findBooking(priceId)].fee == 1000000, "Doi gia sau khong anh huong lich da dat");
	check(rm.createBooking(a, 3, 20261113, 11 * 60, 12 * 60, 2, id) == "" && rm.books[rm.findBooking(id)].fee == 1500000, "Lich moi dung gia moi 1.500.000");
	check(rm.editRoom(owner, 3, "Phong Mai VIP", 1, "VIP", "") != "", "Khong giam suc chua duoi so khach da dat");
	check(rm.deleteRoom(owner, 3) != "", "Khong xoa phong con lich dat");
	int lanId = rm.list[rm.roomCount - 1].id;
	check(rm.deleteRoom(owner, lanId) == "", "Xoa phong Lan (chua co lich) thanh cong");
	check(rm.deleteRoom(staff, 1) != "", "Staff khong duoc xoa phong");
	check(rm.findRoom(lanId) == -1, "Phong Lan da bien mat khoi danh sach");
	check(rm.countBookingsOf(um.list[a].id) > 0 && rm.countBookingsOf(um.list[b].id) > 0, "Moi khach co lich su rieng");
	check(rm.createBooking(artist, 1, 20261114, 10 * 60, 11 * 60, 2, id) == "", "Artist (co quyen dat) dat phong duoc");
	check(formatMoney(2000000) == "2.000.000" && formatMoney(500) == "500", "Dinh dang tien");
	int d = 0, t = 0;
	check(parseDate("2026-02-29", d) == false && parseDate("2028-02-29", d) == true, "Kiem tra ngay nhuan");
	check(parseTime("25:00", t) == false && parseTime("9:30", t) && t == 570, "Kiem tra gio");

	cout << "\n--- KET QUA: " << passed << " dat, " << failed << " loi ---\n";
}

// ---------------------------------------------------------------- main
int main(){
	UserModule um;
	RoomModule rm(&um);
	int c;
	do{
		cout << "\n===== PHONG TRA - MAN HINH CHINH (Guest) =====\n"
		     << "(Tai khoan co san: owner / owner123)\n"
		     << "1. Dang nhap\n2. Dang ky tai khoan\n3. Xem danh sach phong va gia\n"
		     << "4. Xem lich phong trong\n5. Dat phong\n9. Chay kiem thu tu dong\n0. Thoat\n";
		c = inputInt("Chon: ");
		switch(c){
			case 1: {
				int idx = um.login();
				if(idx != -1) goToMenu(rm, um, idx);
				break;
			}
			case 2: um.registerCustomer(); break;
			case 3: rm.showRooms(); break;
			case 4: uiShowSchedule(rm); break;
			case 5: { int tmp = 0; cout << rm.createBooking(-1, 0, 0, 0, 0, 0, tmp) << "\n"; break; }
			case 9: runTests(); break;
			case 0: cout << "Tam biet!\n"; break;
			default: cout << "Lua chon khong hop le.\n";
		}
	}while(c != 0 && cin);
	return 0;
}
