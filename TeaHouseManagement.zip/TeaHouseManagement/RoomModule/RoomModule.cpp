// RoomModule.cpp - CAI DAT module quan ly phong va dat phong
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include "RoomModule.h"
using namespace std;

// ============================================================ Ham tien ich
static bool allDigits(string s){
	if(s.empty()) return false;
	for(unsigned i = 0; i < s.size(); i++){
		if(s[i] < '0' || s[i] > '9') return false;
	}
	return true;
}

static int daysInMonth(int y, int m){
	int d[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
	bool leap = (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0);
	if(m == 2 && leap) return 29;
	return d[m - 1];
}

// Doi ngay yyyymmdd thanh so ngay (tinh tu 01/01/2000) de so sanh khoang cach
static long toDays(int date){
	int y = date / 10000, m = (date / 100) % 100, d = date % 100;
	long days = 0;
	for(int i = 2000; i < y; i++) days += (daysInMonth(i, 2) == 29) ? 366 : 365;
	for(int i = 1; i < m; i++) days += daysInMonth(y, i);
	return days + d;
}

bool parseDate(string s, int &out){
	if(s.size() != 10 || s[4] != '-' || s[7] != '-') return false;
	string ys = s.substr(0, 4), ms = s.substr(5, 2), ds = s.substr(8, 2);
	if(!allDigits(ys) || !allDigits(ms) || !allDigits(ds)) return false;
	int y = atoi(ys.c_str()), m = atoi(ms.c_str()), d = atoi(ds.c_str());
	if(y < 2000 || y > 2100 || m < 1 || m > 12) return false;
	if(d < 1 || d > daysInMonth(y, m)) return false;
	out = y * 10000 + m * 100 + d;
	return true;
}

bool parseTime(string s, int &out){
	size_t colon = s.find(':');
	if(colon == string::npos) return false;
	string hs = s.substr(0, colon), ms = s.substr(colon + 1);
	if(hs.size() < 1 || hs.size() > 2 || ms.size() != 2) return false;
	if(!allDigits(hs) || !allDigits(ms)) return false;
	int h = atoi(hs.c_str()), m = atoi(ms.c_str());
	if(h > 23 || m > 59) return false;
	out = h * 60 + m;
	return true;
}

string formatDate(int d){
	char buf[32];
	sprintf(buf, "%04d-%02d-%02d", d / 10000, (d / 100) % 100, d % 100);
	return string(buf);
}

string formatTime(int minutes){
	char buf[32];
	sprintf(buf, "%02d:%02d", minutes / 60, minutes % 60);
	return string(buf);
}

string formatMoney(long long v){
	string s = to_string(v), r = "";
	int n = (int)s.size();
	for(int i = 0; i < n; i++){
		r += s[i];
		int left = n - 1 - i;
		if(left > 0 && left % 3 == 0) r += '.';
	}
	return r;
}

string roomStatusName(int s){
	if(s == R_FREE) return "Trong";
	if(s == R_IN_USE) return "Dang su dung";
	return "Bao tri";
}

string bookingStatusName(int s){
	if(s == B_BOOKED) return "Da dat";
	if(s == B_CHECKED_IN) return "Dang su dung";
	if(s == B_DONE) return "Da tra phong";
	return "Da huy";
}

bool isValidRoomType(string t){
	return t == "Thuong" || t == "Cao cap" || t == "VIP" || t == "Rieng";
}

// Lam tron LEN theo gio: 1h10 tinh 2 gio. Toi thieu 1 gio.
long long calcRoomFee(long long ratePerHour, int minutes){
	if(minutes < 1) minutes = 1;
	long long hours = (minutes + 59) / 60;
	return hours * ratePerHour;
}

// ===================================================================== Room
Room::Room(){
	id = 0; capacity = 0; pricePerHour = 0; status = R_FREE;
}

Room::Room(int i, string nam, int cap, long long price, string typ, string ame){
	id = i;
	name = nam;
	capacity = cap;
	pricePerHour = price;
	type = typ;
	amenities = ame;
	status = R_FREE;
}

void Room::display(){
	cout << id << "\t" << name << "\t" << type << "\t" << capacity << " nguoi\t"
	     << formatMoney(pricePerHour) << " VND/gio\t" << roomStatusName(status)
	     << "\t" << amenities << "\n";
}

// ================================================================== Booking
Booking::Booking(){
	id = 0; roomId = 0; customerId = 0; date = 0; startMin = 0; endMin = 0;
	guests = 0; status = B_BOOKED; actualEndMin = -1; rate = 0; fee = 0;
}

void Booking::display(){
	cout << "Ma dat phong " << id << ": phong " << roomId << ", khach (ma TK) " << customerId
	     << ", " << formatDate(date) << " " << formatTime(startMin) << "-" << formatTime(endMin)
	     << ", " << guests << " khach, " << bookingStatusName(status)
	     << ", tien thue " << formatMoney(fee) << " VND\n";
}

// ============================================================== RoomModule
RoomModule::RoomModule(UserModule *u){
	users = u;
	roomCount = 0; nextRoomId = 1;
	bookCount = 0; nextBookId = 1;
	time_t t = time(0);
	tm *lt = localtime(&t);
	today = (lt->tm_year + 1900) * 10000 + (lt->tm_mon + 1) * 100 + lt->tm_mday;
	nowMin = lt->tm_hour * 60 + lt->tm_min;

	// Du lieu mau (Owner co the sua gia, xoa, them bat cu luc nao)
	list[roomCount++] = Room(nextRoomId++, "Phong Truc", 6, 500000, "Thuong", "Ban tra, am chen, dieu hoa");
	list[roomCount++] = Room(nextRoomId++, "Phong Sen", 8, 800000, "Cao cap", "Ban tra, am chen, dieu hoa, ghe sofa");
	list[roomCount++] = Room(nextRoomId++, "Phong Mai VIP", 12, 2000000, "VIP", "Ban tra, bo am chen su, dieu hoa, nhac cu, phong rieng");
}

void RoomModule::setNow(int date, int minutes){
	today = date;
	nowMin = minutes;
}

// Cung quy tac voi UserModule::checkAccess: Guest (-1) chi duoc xem thuc don/phong
bool RoomModule::hasPermission(int idx, int feature){
	if(idx == -1) return feature == F_VIEW_MENU;
	if(idx < 0 || idx >= users->count) return false;
	return users->list[idx].can(feature);
}

bool RoomModule::isOwner(int idx){
	if(idx < 0 || idx >= users->count) return false;
	return users->list[idx].role == "Owner" && !users->list[idx].locked;
}

int RoomModule::findRoom(int roomId){
	for(int i = 0; i < roomCount; i++){
		if(list[i].id == roomId) return i;
	}
	return -1;
}

int RoomModule::findBooking(int bookingId){
	for(int i = 0; i < bookCount; i++){
		if(books[i].id == bookingId) return i;
	}
	return -1;
}

int RoomModule::countActiveBookings(int roomId){
	int c = 0;
	for(int i = 0; i < bookCount; i++){
		if(books[i].roomId == roomId && (books[i].status == B_BOOKED || books[i].status == B_CHECKED_IN)) c++;
	}
	return c;
}

int RoomModule::countBookingsOf(int customerId){
	int c = 0;
	for(int i = 0; i < bookCount; i++){
		if(books[i].customerId == customerId) c++;
	}
	return c;
}

// ------------------------------------------------ 1+2. Quan ly phong va gia
string RoomModule::addRoom(int idx, string name, int capacity, long long price, string type, string amenities, int &newId){
	if(!isOwner(idx)) return "Chi Owner moi duoc them phong.";
	if(name.empty()) return "Ten phong khong duoc de trong.";
	if(capacity < 1 || capacity > 100) return "Suc chua phai tu 1 den 100 nguoi.";
	if(price < 1 || price > MAX_PRICE) return "Gia thue phai tu 1 den 20.000.000 VND/gio.";
	if(!isValidRoomType(type)) return "Loai phong phai la: Thuong, Cao cap, VIP hoac Rieng.";
	for(int i = 0; i < roomCount; i++){
		if(list[i].name == name) return "Ten phong da ton tai.";
	}
	if(roomCount >= MAX_ROOMS) return "Danh sach phong da day.";
	newId = nextRoomId;
	list[roomCount++] = Room(nextRoomId++, name, capacity, price, type, amenities);
	return "";
}

string RoomModule::editRoom(int idx, int roomId, string name, int capacity, string type, string amenities){
	if(!isOwner(idx)) return "Chi Owner moi duoc sua phong.";
	int r = findRoom(roomId);
	if(r == -1) return "Khong tim thay phong.";
	if(name.empty()) return "Ten phong khong duoc de trong.";
	if(capacity < 1 || capacity > 100) return "Suc chua phai tu 1 den 100 nguoi.";
	if(!isValidRoomType(type)) return "Loai phong phai la: Thuong, Cao cap, VIP hoac Rieng.";
	for(int i = 0; i < roomCount; i++){
		if(i != r && list[i].name == name) return "Ten phong da ton tai.";
	}
	// Khong cho giam suc chua thap hon so khach cua lich dang con hieu luc
	for(int i = 0; i < bookCount; i++){
		if(books[i].roomId == roomId && (books[i].status == B_BOOKED || books[i].status == B_CHECKED_IN)
		   && books[i].guests > capacity)
			return "Co lich dat dang hieu luc voi so khach lon hon suc chua moi.";
	}
	list[r].name = name;
	list[r].capacity = capacity;
	list[r].type = type;
	list[r].amenities = amenities;
	return "";
}

string RoomModule::setPrice(int idx, int roomId, long long price){
	if(!isOwner(idx)) return "Chi Owner moi duoc cai dat gia thue.";
	int r = findRoom(roomId);
	if(r == -1) return "Khong tim thay phong.";
	if(price < 1 || price > MAX_PRICE) return "Gia thue phai tu 1 den 20.000.000 VND/gio.";
	list[r].pricePerHour = price;   // lich da dat truoc do van giu gia cu (booking.rate)
	return "";
}

string RoomModule::deleteRoom(int idx, int roomId){
	if(!isOwner(idx)) return "Chi Owner moi duoc xoa phong.";
	int r = findRoom(roomId);
	if(r == -1) return "Khong tim thay phong.";
	if(countActiveBookings(roomId) > 0) return "Phong dang co lich dat hoat dong, khong the xoa.";
	for(int i = r; i < roomCount - 1; i++) list[i] = list[i + 1];
	roomCount--;
	return "";
}

// Owner hoac Staff duoc doi trang thai: chi Trong <-> Bao tri (Dang su dung do check-in/check-out tu dong dat)
string RoomModule::setRoomStatus(int idx, int roomId, int status){
	if(!hasPermission(idx, F_ROOM)) return "Ban khong co quyen quan ly phong.";
	int r = findRoom(roomId);
	if(r == -1) return "Khong tim thay phong.";
	if(status != R_FREE && status != R_MAINTENANCE) return "Chi duoc dat Trong hoac Bao tri.";
	if(list[r].status == R_IN_USE) return "Phong dang co khach su dung, hay tra phong truoc.";
	list[r].status = status;
	return "";
}

// ------------------------------------------------------------ Xem thong tin
void RoomModule::showRooms(){
	cout << "\nMa\tTen phong\tLoai\tSuc chua\tGia thue\tTrang thai\tTien ich\n";
	for(int i = 0; i < roomCount; i++) list[i].display();
	if(roomCount == 0) cout << "(Chua co phong nao)\n";
}

// In cac khung gio da dat va cac khung gio con trong cua 1 phong trong 1 ngay
void RoomModule::showSchedule(int roomId, int date){
	int r = findRoom(roomId);
	if(r == -1){ cout << "Khong tim thay phong.\n"; return; }
	cout << "\nLich " << list[r].name << " ngay " << formatDate(date)
	     << " (mo cua " << formatTime(OPEN_MIN) << " - " << formatTime(CLOSE_MIN) << ")\n";
	// Sap xep don gian cac lich dang hieu luc theo gio bat dau
	int order[MAX_BOOKINGS], n = 0;
	for(int i = 0; i < bookCount; i++){
		if(books[i].roomId == roomId && books[i].date == date &&
		   (books[i].status == B_BOOKED || books[i].status == B_CHECKED_IN))
			order[n++] = i;
	}
	for(int i = 0; i < n; i++){
		for(int j = i + 1; j < n; j++){
			if(books[order[j]].startMin < books[order[i]].startMin){
				int t = order[i]; order[i] = order[j]; order[j] = t;
			}
		}
	}
	int cursor = OPEN_MIN;
	for(int i = 0; i < n; i++){
		Booking &b = books[order[i]];
		if(b.startMin > cursor)
			cout << "  TRONG : " << formatTime(cursor) << " - " << formatTime(b.startMin) << "\n";
		cout << "  DA DAT: " << formatTime(b.startMin) << " - " << formatTime(b.endMin) << "\n";
		if(b.endMin > cursor) cursor = b.endMin;
	}
	if(cursor < CLOSE_MIN)
		cout << "  TRONG : " << formatTime(cursor) << " - " << formatTime(CLOSE_MIN) << "\n";
	if(list[r].status == R_MAINTENANCE) cout << "  (Phong dang bao tri, chua nhan dat)\n";
}

// ------------------------------------------------ 3+4. Kiem tra va dat phong
// Kiem tra mot yeu cau dat phong; tra ve "" neu hop le
string RoomModule::checkRequest(int roomId, int date, int startMin, int endMin, int guests, int ignoreBookingId){
	int r = findRoom(roomId);
	if(r == -1) return "Khong tim thay phong.";
	if(list[r].status == R_MAINTENANCE) return "Phong dang bao tri, khong the dat.";
	if(guests < 1) return "So khach phai it nhat 1.";
	if(guests > list[r].capacity) return "So khach vuot suc chua cua phong (toi da " + to_string(list[r].capacity) + " nguoi).";
	if(date < today) return "Khong the dat phong trong qua khu.";
	if(date == today && startMin < nowMin) return "Gio bat dau da qua.";
	if(startMin < OPEN_MIN || endMin > CLOSE_MIN)
		return "Phong tra chi nhan khach tu " + formatTime(OPEN_MIN) + " den " + formatTime(CLOSE_MIN) + ".";
	if(endMin <= startMin) return "Gio ket thuc phai sau gio bat dau.";
	// Trung gio: hai khoang [a,b) va [c,d) trung nhau khi a < d va c < b
	for(int i = 0; i < bookCount; i++){
		Booking &b = books[i];
		if(b.id == ignoreBookingId || b.roomId != roomId || b.date != date) continue;
		if(b.status != B_BOOKED && b.status != B_CHECKED_IN) continue;
		if(startMin < b.endMin && b.startMin < endMin)
			return "Phong da co khach dat trong khung gio " + formatTime(b.startMin) + "-" + formatTime(b.endMin) + ".";
	}
	return "";
}

string RoomModule::createBooking(int idx, int roomId, int date, int startMin, int endMin, int guests, int &newId){
	if(idx == -1) return "Ban can dang nhap de dat phong.";
	if(!hasPermission(idx, F_BOOKING)) return "Ban khong co quyen dat phong.";
	string err = checkRequest(roomId, date, startMin, endMin, guests, -1);
	if(err != "") return err;
	if(bookCount >= MAX_BOOKINGS) return "Danh sach dat phong da day.";
	int r = findRoom(roomId);
	Booking b;
	b.id = nextBookId;
	b.roomId = roomId;
	b.customerId = users->list[idx].id;
	b.date = date;
	b.startMin = startMin;
	b.endMin = endMin;
	b.guests = guests;
	b.status = B_BOOKED;
	b.rate = list[r].pricePerHour;
	b.fee = calcRoomFee(b.rate, endMin - startMin);
	books[bookCount++] = b;
	newId = nextBookId++;
	return "";
}

void RoomModule::showBooking(int bookingId){
	int b = findBooking(bookingId);
	if(b == -1){ cout << "Khong tim thay ma dat phong.\n"; return; }
	books[b].display();
}

// Customer chi thay lich su cua chinh minh
void RoomModule::showMyBookings(int idx){
	if(idx < 0 || idx >= users->count){ cout << "Ban can dang nhap.\n"; return; }
	int myId = users->list[idx].id;
	int c = 0;
	for(int i = 0; i < bookCount; i++){
		if(books[i].customerId == myId){ books[i].display(); c++; }
	}
	if(c == 0) cout << "Ban chua co lich dat phong nao.\n";
}

// ------------------------------------------------------- 5. Quan ly lich dat
void RoomModule::showAllBookings(int date){
	int c = 0;
	for(int i = 0; i < bookCount; i++){
		if(date == 0 || books[i].date == date){ books[i].display(); c++; }
	}
	if(c == 0) cout << "Khong co lich dat phong nao.\n";
}

// Customer huy lich cua chinh minh, phai truoc gio bat dau it nhat CANCEL_BEFORE_MIN phut
string RoomModule::cancelByCustomer(int idx, int bookingId){
	if(idx == -1) return "Ban can dang nhap.";
	if(!hasPermission(idx, F_BOOKING)) return "Ban khong co quyen huy lich.";
	int b = findBooking(bookingId);
	if(b == -1) return "Khong tim thay ma dat phong.";
	if(books[b].customerId != users->list[idx].id) return "Day khong phai lich dat cua ban.";
	if(books[b].status != B_BOOKED) return "Chi huy duoc lich dang o trang thai 'Da dat'.";
	long minutesLeft = (toDays(books[b].date) - toDays(today)) * 1440 + books[b].startMin - nowMin;
	if(minutesLeft < CANCEL_BEFORE_MIN)
		return "Chi duoc huy truoc gio bat dau it nhat " + to_string(CANCEL_BEFORE_MIN / 60) + " gio. Hay lien he nhan vien.";
	books[b].status = B_CANCELLED;
	return "";
}

// Staff/Owner huy lich (khong bi rang buoc thoi gian)
string RoomModule::cancelByStaff(int idx, int bookingId){
	if(!hasPermission(idx, F_ROOM)) return "Ban khong co quyen quan ly lich dat phong.";
	int b = findBooking(bookingId);
	if(b == -1) return "Khong tim thay ma dat phong.";
	if(books[b].status != B_BOOKED) return "Chi huy duoc lich dang o trang thai 'Da dat'.";
	books[b].status = B_CANCELLED;
	return "";
}

// Xac nhan khach den va bat dau su dung phong
string RoomModule::checkIn(int idx, int bookingId){
	if(!hasPermission(idx, F_ROOM)) return "Ban khong co quyen quan ly lich dat phong.";
	int b = findBooking(bookingId);
	if(b == -1) return "Khong tim thay ma dat phong.";
	if(books[b].status != B_BOOKED) return "Lich nay khong o trang thai 'Da dat'.";
	if(books[b].date != today) return "Chi nhan khach vao dung ngay dat (" + formatDate(books[b].date) + ").";
	int r = findRoom(books[b].roomId);
	if(r == -1) return "Phong khong con ton tai.";
	if(list[r].status == R_MAINTENANCE) return "Phong dang bao tri.";
	if(list[r].status == R_IN_USE) return "Phong dang co khach khac su dung.";
	books[b].status = B_CHECKED_IN;
	list[r].status = R_IN_USE;
	return "";
}

// Ghi nhan tra phong va tinh tien thue (lam tron len gio). actualEndMin < 0: lay gio hien tai
string RoomModule::checkOut(int idx, int bookingId, int actualEndMin, long long &fee){
	if(!hasPermission(idx, F_ROOM)) return "Ban khong co quyen quan ly lich dat phong.";
	int b = findBooking(bookingId);
	if(b == -1) return "Khong tim thay ma dat phong.";
	if(books[b].status != B_CHECKED_IN) return "Khach chua vao phong (chua check-in).";
	if(actualEndMin < 0) actualEndMin = nowMin;
	if(actualEndMin > 24 * 60) return "Gio tra phong khong hop le.";
	int used = actualEndMin - books[b].startMin;
	books[b].actualEndMin = actualEndMin;
	books[b].fee = calcRoomFee(books[b].rate, used);
	books[b].status = B_DONE;
	int r = findRoom(books[b].roomId);
	if(r != -1) list[r].status = R_FREE;
	fee = books[b].fee;
	return "";
}

// -------------------------------------- Dau ra cho Module thanh toan (Module 4)
// Tra ve ma dat phong (chinh la bookingId) va so tien. Lich da huy thi khong co tien de thanh toan.
string RoomModule::getPaymentInfo(int bookingId, long long &amount){
	int b = findBooking(bookingId);
	if(b == -1) return "Khong tim thay ma dat phong.";
	if(books[b].status == B_CANCELLED) return "Lich da huy, khong co khoan can thanh toan.";
	amount = books[b].fee;
	return "";
}
