#ifndef PRODUCT_H
#define PRODUCT_H

#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>

using namespace std;

// Cấu trúc quản lý Trà
typedef struct {
    char code1[100];       // Mã trà (VD: "T001")      
    char name[100];        // Tên trà
    long long pricetea;    // Giá trà (VNĐ/100g)
    int quantity;          // Số lượng tồn kho
    int category;          // Phân loại: 1 (Phổ biến), 2 (Cao cấp), 3 (Quy hiếm)
} Tea;

// Cấu trúc quản lý Ấm trà / Dụng cụ
typedef struct {
    char code2[100];       // Mã ấm trà (VD: "A001")
    char teapot[100];      // Tên ấm trà
    char material[100];    // Chất liệu
    long long pricepot;    // Giá (VNĐ/ loại ấm)
    int quantity;          // Số lượng tồn kho
    int category;          // Phân loại: 1 (Phổ biến), 2 (Cao cấp), 3 (Quy hiếm)
} Pot;

// Khai báo nguyên mẫu các hàm quản lý sản phẩm
void displayMenu(Tea menu[], int nTea, Pot menuteapot[], int nPot);
void searchTea(Tea menu[], int nTea, const char *code);
void searchPot(Pot menuteapot[], int nPot, const char *code);
void addProduct(Tea menu[], int *nTea, Pot menuteapot[], int *nPot);
void updateProduct(Tea menu[], int nTea, Pot menuteapot[], int nPot);
void deleteProduct(Tea menu[], int *nTea, Pot menuteapot[], int *nPot);

#endif