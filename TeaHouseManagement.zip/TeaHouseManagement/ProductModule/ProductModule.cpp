#include "Product.h"

// Hiển thị danh sách sản phẩm
void displayMenu(Tea menu[], int nTea, Pot menuteapot[], int nPot) {
    int i;

    // DANH SÁCH TRÀ
    printf("\n");
    printf("============================================================\n");
    printf("                    MENU CAC LOAI TRA                       \n");
    printf("============================================================\n");
    printf("%-5s %-10s %-35s %15s %10s\n", "STT", "Ma tra", "Ten tra", "Gia (VND)", "Ton kho");

    for (i = 0; i < nTea; i++) {
        printf("%-5d %-10s %-35s %15lld %10d\n",
               i + 1, menu[i].code1, menu[i].name, menu[i].pricetea, menu[i].quantity);
    }

    // DANH SÁCH ẤM TRÀ
    printf("\n");
    printf("============================================================\n");
    printf("                    MENU CAC BO AM TRA                      \n");
    printf("============================================================\n");
    printf("%-5s %-10s %-35s %-15s %15s %10s\n",
           "STT", "Ma am", "Ten bo am", "Chat lieu", "Gia (VND)", "Ton kho");

    for (i = 0; i < nPot; i++) {
        printf("%-5d %-10s %-35s %-15s %15lld %10d\n",
               i + 1, menuteapot[i].code2,
               menuteapot[i].teapot,
               menuteapot[i].material,
               menuteapot[i].pricepot,
               menuteapot[i].quantity);
    }
    printf("============================================================\n");
}

// Tìm kiếm trà theo mã
void searchTea(Tea menu[], int nTea, const char *code) {
    int found = 0;
    for (int i = 0; i < nTea; i++) {
        if (strcmp(menu[i].code1, code) == 0) {
            printf("\n-> Tim thay Tra:\n");
            printf("   Ma tra     : %s\n", menu[i].code1);
            printf("   Ten tra    : %s\n", menu[i].name);
            printf("   Gia        : %lld VND/100g\n", menu[i].pricetea);
            printf("   Ton kho    : %d\n", menu[i].quantity);
            found = 1;
            break;
        }
    }
    if (!found) {
        printf("\n-> Khong tim thay ma tra '%s' trong he thong!\n", code);
    }
}

// Tìm kiếm ấm trà theo mã
void searchPot(Pot menuteapot[], int nPot, const char *code) {
    int found = 0;
    for (int i = 0; i < nPot; i++) {
        if (strcmp(menuteapot[i].code2, code) == 0) {
            printf("\n-> Tim thay Bo Am:\n");
            printf("   Ma am      : %s\n", menuteapot[i].code2);
            printf("   Ten bo am  : %s\n", menuteapot[i].teapot);
            printf("   Chat lieu  : %s\n", menuteapot[i].material);
            printf("   Gia        : %lld VND\n", menuteapot[i].pricepot);
            printf("   Ton kho    : %d\n", menuteapot[i].quantity);
            found = 1;
            break;
        }
    }
    if (!found) {
        printf("\n-> Khong tim thay ma am '%s' trong he thong!\n", code);
    }
}

// Thêm sản phẩm mới
void addProduct(Tea menu[], int *nTea, Pot menuteapot[], int *nPot) {
    int choice;
    printf("\n--- THEM SAN PHAM ---\n");
    printf("1. Them Tra moi\n");
    printf("2. Them Bo Am moi\n");
    printf("Chon loai san pham (1-2): ");
    scanf("%d", &choice);

    if (choice == 1) {
        Tea t;
        printf("Nhap ma tra (VD: T031): ");
        scanf("%s", t.code1);
        getchar(); 
        printf("Nhap ten tra: ");
        fgets(t.name, sizeof(t.name), stdin);
        t.name[strcspn(t.name, "\n")] = 0; 
        printf("Nhap gia tra (VND): ");
        scanf("%lld", &t.pricetea);
        printf("Nhap so luong ton kho: ");
        scanf("%d", &t.quantity);
        printf("Phan loai (1: Pho bien, 2: Cao cap, 3: Quy hiem): ");
        scanf("%d", &t.category);

        menu[*nTea] = t;
        (*nTea)++;
        printf("-> Them tra thanh cong!\n");
    } else if (choice == 2) {
        Pot p;
        printf("Nhap ma am (VD: A031): ");
        scanf("%s", p.code2);
        getchar();
        printf("Nhap ten bo am: ");
        fgets(p.teapot, sizeof(p.teapot), stdin);
        p.teapot[strcspn(p.teapot, "\n")] = 0;
        printf("Nhap chat lieu: ");
        fgets(p.material, sizeof(p.material), stdin);
        p.material[strcspn(p.material, "\n")] = 0;
        printf("Nhap gia (VND): ");
        scanf("%lld", &p.pricepot);
        printf("Nhap so luong ton kho: ");
        scanf("%d", &p.quantity);
        printf("Phan loai (1: Pho bien, 2: Cao cap, 3: Quy hiem): ");
        scanf("%d", &p.category);

        menuteapot[*nPot] = p;
        (*nPot)++;
        printf("-> Them bo am thanh cong!\n");
    } else {
        printf("Lua chon khong hop le!\n");
    }
}

// Sửa thông tin sản phẩm
void updateProduct(Tea menu[], int nTea, Pot menuteapot[], int nPot) {
    int choice;
    char code[100];
    printf("\n--- SUA THONG TIN SAN PHAM ---\n");
    printf("1. Sua Tra\n");
    printf("2. Sua Bo Am\n");
    printf("Chon (1-2): ");
    scanf("%d", &choice);

    if (choice == 1) {
        printf("Nhap ma tra can sua: ");
        scanf("%s", code);
        int found = 0;
        for (int i = 0; i < nTea; i++) {
            if (strcmp(menu[i].code1, code) == 0) {
                getchar();
                printf("Nhap ten tra moi: ");
                fgets(menu[i].name, sizeof(menu[i].name), stdin);
                menu[i].name[strcspn(menu[i].name, "\n")] = 0;
                printf("Nhap gia tra moi: ");
                scanf("%lld", &menu[i].pricetea);
                printf("Nhap so luong ton kho moi: ");
                scanf("%d", &menu[i].quantity);
                printf("-> Cap nhat thong tin tra thanh cong!\n");
                found = 1;
                break;
            }
        }
        if (!found) printf("Khong tim thay ma tra nay!\n");
    } else if (choice == 2) {
        printf("Nhap ma am can sua: ");
        scanf("%s", code);
        int found = 0;
        for (int i = 0; i < nPot; i++) {
            if (strcmp(menuteapot[i].code2, code) == 0) {
                getchar();
                printf("Nhap ten bo am moi: ");
                fgets(menuteapot[i].teapot, sizeof(menuteapot[i].teapot), stdin);
                menuteapot[i].teapot[strcspn(menuteapot[i].teapot, "\n")] = 0;
                printf("Nhap chat lieu moi: ");
                fgets(menuteapot[i].material, sizeof(menuteapot[i].material), stdin);
                menuteapot[i].material[strcspn(menuteapot[i].material, "\n")] = 0;
                printf("Nhap gia moi: ");
                scanf("%lld", &menuteapot[i].pricepot);
                printf("Nhap so luong ton kho moi: ");
                scanf("%d", &menuteapot[i].quantity);
                printf("-> Cap nhat thong tin bo am thanh cong!\n");
                found = 1;
                break;
            }
        }
        if (!found) printf("Khong tim thay ma am nay!\n");
    }
}

// Xóa sản phẩm khỏi danh sách
void deleteProduct(Tea menu[], int *nTea, Pot menuteapot[], int *nPot) {
    int choice;
    char code[100];
    printf("\n--- XOA SAN PHAM ---\n");
    printf("1. Xoa Tra\n");
    printf("2. Xoa Bo Am\n");
    printf("Chon (1-2): ");
    scanf("%d", &choice);

    if (choice == 1) {
        printf("Nhap ma tra can xoa: ");
        scanf("%s", code);
        int found = -1;
        for (int i = 0; i < *nTea; i++) {
            if (strcmp(menu[i].code1, code) == 0) {
                found = i;
                break;
            }
        }
        if (found != -1) {
            for (int i = found; i < *nTea - 1; i++) {
                menu[i] = menu[i + 1];
            }
            (*nTea)--;
            printf("-> Xoa tra thanh cong!\n");
        } else {
            printf("Khong tim thay ma tra!\n");
        }
    } else if (choice == 2) {
        printf("Nhap ma am can xoa: ");
        scanf("%s", code);
        int found = -1;
        for (int i = 0; i < *nPot; i++) {
            if (strcmp(menuteapot[i].code2, code) == 0) {
                found = i;
                break;
            }
        }
        if (found != -1) {
            for (int i = found; i < *nPot - 1; i++) {
                menuteapot[i] = menuteapot[i + 1];
            }
            (*nPot)--;
            printf("-> Xoa bo am thanh cong!\n");
        } else {
            printf("Khong tim thay ma am!\n");
        }
    }
}