TeaHouseManagement - organized project structure

The files from the supplied tea.zip have been arranged into the requested module layout.

Notes:
- main.cpp is an empty placeholder because no root main.cpp was present in the source ZIP.
- The Data/*.txt files are empty placeholders because no data files were present in the source ZIP.
- Models.h was copied from SalesModule/Models.h to the project root to match the requested layout; the original module file remains in SalesModule.
- Product.cpp and Product.h were renamed to ProductModule.cpp and ProductModule.h to match the requested naming convention.
- RoomModule/legacy contains the extra UserModule.h/.cpp files that were originally inside RoomModule, so no supplied source files are lost.
